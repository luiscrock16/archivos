@echo off
setlocal EnableDelayedExpansion
title Instalador Automatico de Touchpad - Canaima (x86 32-bit)
color 0b

:: 1. Verificacion de permisos de Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo =======================================================
    echo   SOLICITANDO PERMISOS DE ADMINISTRADOR...
    echo =======================================================
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
cls
echo ======================================================================
echo    INSTALADOR Y ACTIVADOR DE TOUCHPAD PARA CANAIMA (x86 / 32-bit)
echo                 Compatible con MiniOS 10 / Windows 10
echo ======================================================================
echo.
echo Este script realizara las siguientes acciones:
echo   1. Reactivar el servicio del puerto PS/2 (i8042prt) en el registro
echo      (comunmente deshabilitado en versiones MiniOS/Lite).
echo   2. Inyectar e instalar los controladores Synaptics Pointing Device (x86).
echo   3. Inyectar e instalar los controladores ELAN Microelectronics (x86).
echo   4. Forzar re-escaneo de hardware para levantar el panel tactil.
echo.
echo Presione cualquier tecla para iniciar el proceso...
pause >nul
echo.

:: 2. Reactivacion de servicio PS/2 i8042prt
echo [1/4] Reactivando servicio de hardware PS/2 en el Registro de Windows...
reg add "HKLM\SYSTEM\CurrentControlSet\Services\i8042prt" /v Start /t REG_DWORD /d 1 /f >nul 2>&1
sc config i8042prt start= auto >nul 2>&1
echo       - Servicio i8042prt configurado en inicio automatico.
echo.

:: 3. Instalacion de Controladores Synaptics
echo [2/4] Instalando controladores Synaptics TouchPad (Win10 x86)...
if exist "%~dp01_Synaptics_Touchpad_Win10_x86" (
    pnputil /add-driver "%~dp01_Synaptics_Touchpad_Win10_x86\*.inf" /subdirs /install >nul 2>&1
    if %errorlevel% neq 0 (
        for /r "%~dp01_Synaptics_Touchpad_Win10_x86" %%f in (*.inf) do (
            pnputil.exe -i -a "%%f" >nul 2>&1
        )
    )
    echo       - Controladores Synaptics procesados correctamente.
) else (
    echo       [AVISO] No se encontro la carpeta 1_Synaptics_Touchpad_Win10_x86.
)
echo.

:: 4. Instalacion de Controladores ELAN
echo [3/4] Instalando controladores ELAN Microelectronics TouchPad (x86)...
if exist "%~dp02_ELAN_Touchpad_x86" (
    pnputil /add-driver "%~dp02_ELAN_Touchpad_x86\*.inf" /subdirs /install >nul 2>&1
    if %errorlevel% neq 0 (
        for /r "%~dp02_ELAN_Touchpad_x86" %%f in (*.inf) do (
            pnputil.exe -i -a "%%f" >nul 2>&1
        )
    )
    echo       - Controladores ELAN procesados correctamente.
) else (
    echo       [AVISO] No se encontro la carpeta 2_ELAN_Touchpad_x86.
)
echo.

:: 5. Forzar re-escaneo de dispositivos Plug and Play
echo [4/4] Forzando deteccion y actualizacion de hardware...
pnputil /scan-devices >nul 2>&1
echo       - Deteccion de hardware completada.
echo.

echo ======================================================================
echo                      PROCESO COMPLETADO
echo ======================================================================
echo.
echo NOTA IMPORTANTE SI EL TOUCHPAD SIGUE SIN RESPONDER:
echo   1. Revisa si esta bloqueado por teclado:
echo      - Presiona la combinacion Fn + F1  o  Fn + F6  o  Fn + F7.
echo      - En modelos Canaima Letras Azules / Rojas, revisa si hay un LED
echo        pequeno en la esquina superior izquierda del touchpad. Dale dos
echo        toques rapidos con el dedo sobre esa esquina para desbloquearlo.
echo.
echo   2. Si el sistema te pide reiniciar para aplicar los cambios del puerto
echo      PS/2, hazlo ahora.
echo.
set /p REBOOT="Deseas reiniciar la laptop ahora mismo? (S/N): "
if /i "%REBOOT%"=="S" (
    echo Reiniciando sistema en 5 segundos...
    shutdown /r /t 5
) else (
    echo Puedes reiniciar mas tarde manualmente.
)
pause
