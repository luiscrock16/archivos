@echo off
setlocal EnableDelayedExpansion
title Instalador de Office Completo - Canaimas (MiniOS 10)
color 0b

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
cls
echo ======================================================================
echo       INSTALADOR DE OFFICE COMPLETO PARA CANAIMA (MiniOS 10)
echo         Arquitectura: 32 bits (x86) - Suite Profesional
echo ======================================================================
echo.
echo Aplicaciones que se van a instalar:
echo   - Microsoft Word, Excel, PowerPoint
echo   - Microsoft Outlook, OneNote, Access, Publisher
echo.
if exist "%~dp0Office" (
    echo [MODO DETECTADO]: INSTALACION LOCAL OFFLINE.
) else (
    echo [MODO DETECTADO]: INSTALACION EN LINEA (Descarga directa desde Microsoft).
    echo Asegurate de que la Canaima este conectada a Internet.
)
echo.
echo Presiona cualquier tecla para comenzar...
pause >nul
echo.
echo Instalando... Por favor espera.
"%~dp0setup.exe" /configure "%~dp0config_canaima_completo.xml"

echo.
echo ======================================================================
echo                      INSTALACION FINALIZADA
echo ======================================================================
pause
