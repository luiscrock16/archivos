@echo off
setlocal EnableDelayedExpansion
title Instalador Automatico de Office Ligero - Canaimas (MiniOS 10)
color 0b

:: 1. Verificacion de permisos de Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo =======================================================
    echo   SOLICITANDO PERMISOS DE ADMINISTRADOR...
    echo =======================================================
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
cls
echo ======================================================================
echo       INSTALADOR DE OFFICE LIGERO PARA CANAIMA (MiniOS 10)
echo         Arquitectura: 32 bits (x86) - Optimizada para 1GB/2GB RAM
echo ======================================================================
echo.
echo Aplicaciones que se van a instalar:
echo   - Microsoft Word
echo   - Microsoft Excel
echo   - Microsoft PowerPoint
echo.
echo (Se han desactivado aplicaciones pesadas como Teams, OneDrive y
echo  telemetria para que la Canaima no se ponga lenta).
echo.
if exist "%~dp0Office" (
    echo [MODO DETECTADO]: INSTALACION LOCAL OFFLINE (Archivos encontrados en la carpeta).
) else (
    echo [MODO DETECTADO]: INSTALACION EN LINEA (Descarga directa desde Microsoft).
    echo Asegurate de que la Canaima este conectada a WiFi o cable de red.
)
echo.
echo Presiona cualquier tecla para comenzar la instalacion automatica...
pause >nul
echo.
echo Instalando Microsoft Office... Por favor espera unos minutos.
echo (La ventana de instalacion oficial de Office se abrira en pantalla).
echo.

"%~dp0setup.exe" /configure "%~dp0config_canaima_ligero.xml"

echo.
echo ======================================================================
echo                      INSTALACION FINALIZADA
echo ======================================================================
echo.
echo Ya puedes abrir Word, Excel y PowerPoint desde el Menu Inicio.
pause
