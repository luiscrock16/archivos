@echo off
setlocal EnableDelayedExpansion
title Descargador de Office Offline para Pendrive / USB
color 0a

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
cls
echo ======================================================================
echo    DESCARGADOR DE OFFICE OFFLINE PARA PENDRIVE (32 BITS)
echo ======================================================================
echo.
echo Este script descargara el instalador completo de Office en esta carpeta.
echo.
echo UTILIDAD:
echo   Ejecuta esto en una computadora con buen internet para que se cree
echo   la carpeta "Office". Luego llevas este pendrive a las Canaimas de
echo   la escuela y podras instalar Office 100%% SIN CONEXION A INTERNET.
echo.
echo Presiona cualquier tecla para iniciar la descarga...
pause >nul
echo.
echo Descargando archivos oficiales de Microsoft... Por favor espera.
echo (Esta ventana se cerrara automaticamente cuando termine).
echo.

"%~dp0setup.exe" /download "%~dp0config_canaima_ligero.xml"

echo.
echo ======================================================================
echo                      DESCARGA COMPLETADA
echo ======================================================================
echo.
echo Se ha creado la carpeta "Office" con todos los paquetes necesarios.
echo Ahora puedes llevar este pendrive a cualquier Canaima e instalarlo
echo sin necesidad de internet con "1_INSTALAR_OFFICE_LIGERO.bat".
pause
