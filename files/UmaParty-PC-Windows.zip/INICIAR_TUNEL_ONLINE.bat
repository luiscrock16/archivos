@echo off
title Cloudflare Tunnel - Servidor Online Uma Party Dash
color 0B
echo ======================================================================
echo           TUNEL PUBLICO PARA UMA PARTY DASH (WINDOWS)
echo ======================================================================
echo.
echo  1. Inicia "UmaParty.exe".
echo  2. En el menu principal selecciona:
echo     "Modo Red: Web & Online (WebSocket)"
echo  3. Haz clic en "CREAR SALA (HOST)".
echo.
echo  Conectando con Cloudflare para crear tu sala publica...
echo  Copia la URL que termine en ".trycloudflare.com" (ej: https://xxxx.trycloudflare.com)
echo  y pasasela a tus amigos o ingresala en la casilla de IP en Itch.io!
echo ======================================================================
echo.

"%~dp0cloudflared.exe" tunnel --url http://localhost:8080
pause
