# 🏫 Sistema Institucional - Colegio Divina Providencia
### Servidor Web Local Autónomo para Red Interna Escolar

Este sistema ha sido diseñado y desarrollado especialmente para funcionar de manera **100% local e independiente** dentro de las instalaciones del **Colegio Divina Providencia**, sin requerir internet, sin mensualidades ni dependencias en la nube.

---

## 🌟 Características Principales

- **Arquitectura Servidor Local (LAN / Wi-Fi):** Se ejecuta en una computadora principal designada como "Servidor", y cualquier otra computadora secundaria de la institución (Coordinación, Secretaría, Docentes, Dirección o Alumnos) puede conectarse a través del navegador web usando la red de la institución.
- **Identidad Institucional Elegante:** Colores oficiales Azul Marino (`#1E3A8A`), Azul Real (`#2563EB`) y Blanco puro, con el escudo e insignia oficial del Colegio Divina Providencia.
- **Gestión de Horarios y Exportación en PDF:**
  - Visualización interactiva semanal (Lunes a Viernes) por Nivel (Primaria, Bachillerato), Grado/Año y Sección.
  - Bloques de horario completos con asignaturas, profesores a cargo y aulas.
  - Botón **"Descargar Horario en PDF"** e **"Imprimir"**, adaptados automáticamente a formato oficial con membrete del colegio, sellos y firmas de coordinación y dirección.
- **Gestor de Contenidos y Noticias (CMS Local):**
  - Publicación y edición de artículos, noticias escolares, eventos deportivos, convocatorias académicas y comunicados oficiales.
  - Subida y almacenamiento local de imágenes directamente en el disco duro del servidor escolar (`data/uploads/`).
- **Módulo de Admisiones y Pre-inscripciones:**
  - Formulario de solicitud para aspirantes con datos del alumno y del representante legal.
  - Generación instantánea de **Código Único de Registro** (ej. `INS-2026-0001`).
  - Consulta pública de estado del trámite (`Pendiente`, `Aprobado`, `En Revisión`, `Rechazado`).
  - Panel de secretaría para revisar expedientes, cambiar estados, agregar notas de recaudos e imprimir comprobantes.
- **Mantenimiento y Base de Datos Autónoma:**
  - Base de datos integrada (`data/database.json`) con escritura atómica segura ante cortes de energía eléctrica.
  - Sistema de **Copias de Seguridad (Backup)** automáticas y manuales en 1 clic en formato JSON para guardar en pendrives o discos duros externos.
  - Módulo de restauración de copias de seguridad.
  - Registro de auditoría (historial de actividades por fecha y usuario).
- **Control de Acceso y Roles:**
  - `admin`: Acceso total (configuración institucional, usuarios, base de datos).
  - `coordinador`: Gestión de horarios académicos y publicación de artículos.
  - `secretaria`: Gestión de inscripciones, comunicados y consulta de alumnos.

---

## 🚀 Cómo Iniciar el Servidor

### 1. En la Computadora Principal ("Servidor")
1. Abre la carpeta `pagina`.
2. Haz doble clic en el archivo **`iniciar_servidor.bat`**.
3. Se abrirá la consola del servidor mostrando el estado y se abrirá automáticamente tu navegador en:
   ```
   http://localhost:5000
   ```
4. En la consola verás las direcciones IP de la red local (por ejemplo: `http://192.168.1.50:5000`).

### 2. En Computadoras Secundarias (Otras PCs de la Escuela)
1. Asegúrate de que la computadora secundaria esté conectada al mismo WiFi o cable de red del colegio.
2. Abre cualquier navegador (Google Chrome, Microsoft Edge, Mozilla Firefox).
3. Escribe en la barra de direcciones la IP que mostró el servidor:
   ```
   http://<IP-DE-LA-PC-SERVIDOR>:5000
   ```
   *(Ejemplo: `http://192.168.1.50:5000`)*
4. ¡Listo! Tendrás acceso inmediato al portal público o al panel administrativo si tienes clave autorizada.

---

## 🔐 Cuentas de Acceso Preconfiguradas

| Usuario | Contraseña | Rol / Nivel de Acceso |
| :--- | :--- | :--- |
| **`admin`** | `admin123` | **Administrador General** (Control total del sistema) |
| **`coordinador`** | `coord123` | **Coordinador Académico** (Horarios y Artículos) |
| **`secretaria`** | `secre123` | **Secretaría** (Inscripciones, expedientes y comunicados) |

> 💡 *Nota de seguridad:* Puedes cambiar o crear nuevos usuarios en cualquier momento desde el panel: **Panel Administrativo → Usuarios y Roles**.

---

## 📁 Estructura del Proyecto

```
pagina/
├── ColegioServidor.exe      # Ejecutable del servidor local de alta velocidad
├── iniciar_servidor.bat     # Lanzador en 1 clic para Windows (Abre navegador e inicia servidor)
├── build.bat                # Compilador por si realizas cambios al código C#
├── README.md                # Este manual de uso
├── src/                     # Código fuente del Servidor en C#
│   ├── Program.cs          # Entrada principal, detección de interfaces de red local
│   ├── Server.cs           # Servidor HTTP/1.1 multi-hilo de alto rendimiento
│   ├── ApiHandler.cs       # API REST (Noticias, Horarios, Inscripciones, Backups)
│   ├── Database.cs         # Motor de base de datos local JSON con protección ante fallas
│   ├── Auth.cs             # Autenticación, contraseñas seguras SHA-256 y sesiones
│   └── Models.cs           # Modelos de datos de la escuela
├── wwwroot/                 # Aplicación Web Frontend (HTML, CSS, JS, Gráficos)
│   ├── index.html          # Portal institucional y panel de administración
│   ├── css/
│   │   ├── main.css        # Estilos modernos azul y blanco, responsive
│   │   └── print.css       # Formato optimizado para impresión y PDF
│   ├── js/
│   │   ├── app.js          # Lógica pública, buscador de horarios, inscripciones
│   │   └── admin.js        # Lógica del panel administrativo (CMS, horarios, auditoría)
│   └── images/
│       ├── logo.svg        # Escudo oficial del Colegio Divina Providencia
│       ├── noticia1.svg    # Imagen representativa Apertura Escolar
│       ├── noticia2.svg    # Imagen representativa Ciencia y Tecnología
│       ├── noticia3.svg    # Imagen representativa Juegos Deportivos
│       └── noticia4.svg    # Imagen representativa Comunicado Oficial
└── data/                    # Almacenamiento local de datos
    ├── database.json       # Base de datos activa
    ├── uploads/            # Imágenes subidas localmente para las noticias
    └── backups/            # Copias de seguridad automáticas y manuales
```

---

## 🛡️ Configuración del Firewall de Windows (Si una PC secundaria no conecta)

Si las computadoras secundarias no logran abrir la página, el Firewall de Windows en la PC Servidor puede estar bloqueando conexiones entrantes en el puerto 5000. Para habilitarlo en 1 minuto:

1. En la PC Servidor, presiona la tecla `Windows` y busca **"Firewall de Windows Defender"**.
2. Haz clic en **"Configuración avanzada"** (a la izquierda).
3. Selecciona **"Reglas de entrada"** → **"Nueva regla..."** (a la derecha).
4. Elige **Puerto** → Siguiente.
5. Selecciona **TCP** y en "Puertos locales específicos" escribe: `5000` → Siguiente.
6. Elige **"Permitir la conexión"** → Siguiente → Deja marcadas todas las casillas → Siguiente.
7. Asigna el nombre: `Colegio Divina Providencia Servidor` y haz clic en **Finalizar**.
