/**
 * Colegio Divina Providencia - Script Principal de la Aplicación
 */

const app = {
  settings: null,
  currentUser: null,
  articles: [],
  schedules: [],
  currentSchedule: null,

  async init() {
    await this.loadSettings();
    await this.checkAuth();
    await this.loadArticles();
    await this.loadSchedules();

    // Check URL hash for direct tab navigation
    const hash = window.location.hash.replace('#', '');
    if (hash && document.getElementById('tab-' + hash)) {
      this.showTab(hash);
    }
  },

  // ================= SETTINGS =================
  async loadSettings() {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        this.settings = await res.json();
        this.applySettings();
      }
    } catch (e) {
      console.warn('No se pudo cargar la configuración:', e);
    }
  },

  applySettings() {
    if (!this.settings) return;
    const s = this.settings;

    // Header & Brand
    document.title = s.SchoolName + ' | Sistema Institucional';
    const brandName = document.getElementById('brand-school-name');
    if (brandName) brandName.textContent = s.SchoolName;

    const brandSlogan = document.getElementById('brand-school-slogan');
    if (brandSlogan) brandSlogan.textContent = s.Slogan;

    // Top Bar
    const topAddress = document.getElementById('top-address');
    if (topAddress) topAddress.textContent = s.Address;

    const topPhone = document.getElementById('top-phone');
    if (topPhone) topPhone.textContent = s.Phone;

    const topPill = document.getElementById('top-enrollment-pill');
    if (topPill) {
      topPill.textContent = s.EnrollmentOpen ? 'Inscripciones Abiertas' : 'Inscripciones Finalizadas';
      topPill.className = s.EnrollmentOpen ? 'badge-academico' : 'badge-comunicado';
    }

    // Hero
    const heroTitle = document.getElementById('hero-welcome-title');
    if (heroTitle) heroTitle.textContent = s.WelcomeTitle || 'Bienvenidos al ' + s.SchoolName;

    const heroText = document.getElementById('hero-welcome-text');
    if (heroText) heroText.textContent = s.WelcomeText || s.Slogan;

    const heroNotice = document.getElementById('hero-card-notice');
    if (heroNotice) heroNotice.textContent = s.EnrollmentNotice || 'Proceso de inscripciones disponible.';

    // Institution Tab
    const instMission = document.getElementById('inst-mission');
    if (instMission) instMission.textContent = s.Mission;

    const instVision = document.getElementById('inst-vision');
    if (instVision) instVision.textContent = s.Vision;

    const instHistory = document.getElementById('inst-history');
    if (instHistory) instHistory.textContent = s.History;

    const instValues = document.getElementById('inst-values');
    if (instValues) instValues.textContent = s.Values;

    const instPrincipal = document.getElementById('inst-principal');
    if (instPrincipal) instPrincipal.textContent = s.PrincipalName;

    // Contact Tab
    const contactAddress = document.getElementById('contact-address');
    if (contactAddress) contactAddress.textContent = s.Address;

    const contactPhone = document.getElementById('contact-phone');
    if (contactPhone) contactPhone.textContent = s.Phone;

    const contactEmail = document.getElementById('contact-email');
    if (contactEmail) contactEmail.textContent = s.Email;

    const contactHours = document.getElementById('contact-hours');
    if (contactHours) contactHours.textContent = s.OfficeHours;

    // Footer
    const footerSlogan = document.getElementById('footer-slogan');
    if (footerSlogan) footerSlogan.textContent = s.Slogan;

    const footerAddress = document.getElementById('footer-address');
    if (footerAddress) footerAddress.textContent = '📍 ' + s.Address;

    const footerPhone = document.getElementById('footer-phone');
    if (footerPhone) footerPhone.textContent = '📞 ' + s.Phone;

    const footerHours = document.getElementById('footer-hours');
    if (footerHours) footerHours.textContent = '⏰ ' + s.OfficeHours;
  },

  // ================= TAB NAVIGATION =================
  showTab(tabId) {
    const tabs = document.querySelectorAll('.tab-view');
    tabs.forEach(t => t.style.display = 'none');

    const hero = document.getElementById('hero-section');
    if (hero) {
      hero.style.display = (tabId === 'inicio') ? 'block' : 'none';
    }

    const target = document.getElementById('tab-' + tabId);
    if (target) {
      target.style.display = 'block';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Update active nav link
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(l => l.classList.remove('active'));

    const activeLink = document.querySelector(`.nav-link[onclick*="'${tabId}'"]`);
    if (activeLink) activeLink.classList.add('active');

    // Close mobile menu if open
    const menu = document.getElementById('nav-menu');
    if (menu) menu.classList.remove('open');

    // Tab specific triggers
    if (tabId === 'horarios' && !this.currentSchedule && this.schedules.length > 0) {
      this.renderSchedule(this.schedules[0]);
    }
    if (tabId === 'admin') {
      if (!this.currentUser) {
        this.openLoginModal();
      } else {
        adminApp.init();
      }
    }
  },

  toggleMenu() {
    const menu = document.getElementById('nav-menu');
    if (menu) menu.classList.toggle('open');
  },

  // ================= ARTICLES / NEWS =================
  async loadArticles() {
    try {
      const res = await fetch('/api/articles');
      if (res.ok) {
        this.articles = await res.json();
        this.renderHomeNews();
        this.renderFullNews(this.articles);
      }
    } catch (e) {
      console.warn('Error cargando artículos:', e);
    }
  },

  renderHomeNews() {
    const container = document.getElementById('home-news-grid');
    if (!container) return;

    const latest = this.articles.slice(0, 3);
    if (latest.length === 0) {
      container.innerHTML = '<p style="color: #64748b; grid-column: 1/-1; text-align: center;">No hay comunicados publicados recientemente.</p>';
      return;
    }

    container.innerHTML = latest.map(a => this.createNewsCardHtml(a)).join('');
  },

  renderFullNews(list) {
    const container = document.getElementById('full-news-grid');
    if (!container) return;

    if (list.length === 0) {
      container.innerHTML = '<p style="color: #64748b; grid-column: 1/-1; text-align: center; padding: 40px;">No se encontraron noticias en esta categoría.</p>';
      return;
    }

    container.innerHTML = list.map(a => this.createNewsCardHtml(a)).join('');
  },

  createNewsCardHtml(a) {
    const catClass = 'badge-' + (a.Category || 'noticia').toLowerCase();
    const catName = this.formatCategoryName(a.Category);
    const imgUrl = a.ImageUrl || '/images/noticia1.svg';

    return `
      <div class="news-card" onclick="app.viewArticle('${a.Id}')">
        <div class="news-img-wrapper">
          <img src="${imgUrl}" alt="${this.escapeHtml(a.Title)}" class="news-img" loading="lazy">
          <span class="news-badge ${catClass}">${catName}</span>
        </div>
        <div class="news-body">
          <div class="news-meta">
            <span>📅 ${a.PublishedAt || 'Reciente'}</span>
            <span>✍️ ${this.escapeHtml(a.Author || 'Colegio')}</span>
          </div>
          <h3 class="news-title">${this.escapeHtml(a.Title)}</h3>
          <p class="news-summary">${this.escapeHtml(a.Summary || '')}</p>
          <div class="news-footer">
            <span>Leer noticia completa</span>
            <span>→</span>
          </div>
        </div>
      </div>
    `;
  },

  formatCategoryName(cat) {
    switch ((cat || '').toLowerCase()) {
      case 'evento': return 'Evento';
      case 'academico': return 'Académico';
      case 'comunicado': return 'Comunicado';
      default: return 'Noticia';
    }
  },

  filterNews(category) {
    // Update active button state
    const btns = document.querySelectorAll('#news-categories button');
    btns.forEach(b => {
      b.className = 'btn btn-outline-white';
      b.style.color = 'var(--primary)';
      b.style.borderColor = 'var(--border)';
    });

    const activeBtn = document.getElementById('btn-cat-' + category);
    if (activeBtn) {
      activeBtn.className = 'btn btn-primary';
      activeBtn.style.color = '#ffffff';
      activeBtn.style.backgroundColor = 'var(--primary)';
    }

    if (category === 'all') {
      this.renderFullNews(this.articles);
    } else {
      const filtered = this.articles.filter(a => (a.Category || '').toLowerCase() === category.toLowerCase());
      this.renderFullNews(filtered);
    }
  },

  searchNews(query) {
    const q = query.trim().toLowerCase();
    if (!q) {
      this.renderFullNews(this.articles);
      return;
    }

    const filtered = this.articles.filter(a =>
      (a.Title && a.Title.toLowerCase().includes(q)) ||
      (a.Summary && a.Summary.toLowerCase().includes(q)) ||
      (a.Content && a.Content.toLowerCase().includes(q))
    );
    this.renderFullNews(filtered);
  },

  viewArticle(id) {
    const article = this.articles.find(a => a.Id === id);
    if (!article) return;

    document.getElementById('article-modal-title').textContent = article.Title;
    document.getElementById('article-modal-date').textContent = article.PublishedAt || 'Reciente';
    document.getElementById('article-modal-author').textContent = article.Author || 'Colegio Divina Providencia';
    document.getElementById('article-modal-summary').textContent = article.Summary || '';
    document.getElementById('article-modal-content').textContent = article.Content || '';

    const catBadge = document.getElementById('article-modal-category');
    catBadge.textContent = this.formatCategoryName(article.Category);
    catBadge.className = 'news-badge badge-' + (article.Category || 'noticia').toLowerCase();

    const img = document.getElementById('article-modal-img');
    const wrap = document.getElementById('article-modal-img-wrap');
    if (article.ImageUrl) {
      img.src = article.ImageUrl;
      wrap.style.display = 'block';
    } else {
      wrap.style.display = 'none';
    }

    this.openModal('modal-article');
  },

  // ================= SCHEDULES & PDF =================
  async loadSchedules() {
    try {
      const res = await fetch('/api/schedules');
      if (res.ok) {
        this.schedules = await res.json();
        this.populateScheduleFilters();
        if (this.schedules.length > 0) {
          this.renderSchedule(this.schedules[0]);
        }
      }
    } catch (e) {
      console.warn('Error cargando horarios:', e);
    }
  },

  populateScheduleFilters() {
    const gradeSelect = document.getElementById('sched-filter-grade');
    if (!gradeSelect) return;

    // Unique grades
    const grades = [...new Set(this.schedules.map(s => s.Grade))];
    gradeSelect.innerHTML = '<option value="">Todos los grados</option>' +
      grades.map(g => `<option value="${this.escapeHtml(g)}">${this.escapeHtml(g)}</option>`).join('');
  },

  filterSchedules() {
    const level = document.getElementById('sched-filter-level').value;
    const grade = document.getElementById('sched-filter-grade').value;
    const section = document.getElementById('sched-filter-section').value;

    const filtered = this.schedules.filter(s => {
      if (level && s.Level !== level) return false;
      if (grade && s.Grade !== grade) return false;
      if (section && s.Section !== section) return false;
      return true;
    });

    if (filtered.length > 0) {
      this.renderSchedule(filtered[0]);
    } else {
      const table = document.getElementById('schedule-grid-table');
      if (table) {
        table.innerHTML = '<tr><td colspan="6" style="padding: 40px; color: #64748b;">No se encontró ningún horario con los filtros seleccionados.</td></tr>';
      }
    }
  },

  renderSchedule(sch) {
    this.currentSchedule = sch;
    if (!sch) return;

    const displayGrade = document.getElementById('sched-display-grade');
    if (displayGrade) displayGrade.textContent = `${sch.Grade} - Sección ${sch.Section} (${sch.Level || 'Bachillerato'})`;

    const displayShift = document.getElementById('sched-display-shift');
    if (displayShift) displayShift.textContent = sch.Shift || 'Mañana';

    const displayRoom = document.getElementById('sched-display-room');
    if (displayRoom) displayRoom.textContent = sch.Classroom || 'Aula Asignada';

    const displayCoord = document.getElementById('sched-display-coord');
    if (displayCoord) displayCoord.textContent = sch.Coordinator || 'Coordinación';

    const displayYear = document.getElementById('sched-display-year');
    if (displayYear) displayYear.textContent = sch.SchoolYear || '2026-2027';

    // Build Weekly Grid Table
    const table = document.getElementById('schedule-grid-table');
    if (!table) return;

    const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];

    // Collect all unique time slots across days
    const timeSlots = [];
    (sch.Days || []).forEach(d => {
      (d.Periods || []).forEach(p => {
        if (p.Time && !timeSlots.includes(p.Time)) {
          timeSlots.push(p.Time);
        }
      });
    });

    // If no periods, show empty message
    if (timeSlots.length === 0) {
      table.innerHTML = '<tr><td colspan="6" style="padding: 30px;">Este curso aún no tiene bloques de clase asignados.</td></tr>';
      return;
    }

    let html = `
      <thead>
        <tr>
          <th style="width: 140px;">Horario</th>
          <th>Lunes</th>
          <th>Martes</th>
          <th>Miércoles</th>
          <th>Jueves</th>
          <th>Viernes</th>
        </tr>
      </thead>
      <tbody>
    `;

    timeSlots.forEach(time => {
      const isRecess = time.toLowerCase().includes('receso') || time.includes('09:15 - 09:45') || time.includes('09:30 - 10:00');

      if (isRecess) {
        html += `
          <tr class="recess-row">
            <td class="time-col">${time}</td>
            <td colspan="5" style="letter-spacing: 2px;">RECESO / DESCANSO PEDAGÓGICO</td>
          </tr>
        `;
      } else {
        html += `<tr><td class="time-col">${time}</td>`;

        days.forEach(dayName => {
          const dayObj = (sch.Days || []).find(d => d.Day && d.Day.toLowerCase() === dayName.toLowerCase());
          const period = dayObj ? (dayObj.Periods || []).find(p => p.Time === time) : null;

          if (period && period.Subject) {
            html += `
              <td>
                <span class="subject-name">${this.escapeHtml(period.Subject)}</span>
                ${period.Teacher ? `<span class="teacher-name">${this.escapeHtml(period.Teacher)}</span>` : ''}
                ${period.Room ? `<span class="room-badge">${this.escapeHtml(period.Room)}</span>` : ''}
              </td>
            `;
          } else {
            html += `<td style="color: #cbd5e1;">-</td>`;
          }
        });

        html += `</tr>`;
      }
    });

    html += `</tbody>`;
    table.innerHTML = html;
  },

  downloadSchedulePDF() {
    if (!this.currentSchedule) {
      alert('Por favor selecciona un horario primero.');
      return;
    }
    // Directly invoke print dialog formatted specifically for PDF output
    window.print();
  },

  // ================= ENROLLMENTS =================
  async submitEnrollment(e) {
    e.preventDefault();

    const data = {
      StudentFirstName: document.getElementById('enr-student-first').value.trim(),
      StudentLastName: document.getElementById('enr-student-last').value.trim(),
      StudentDocId: document.getElementById('enr-student-doc').value.trim(),
      BirthDate: document.getElementById('enr-student-birth').value,
      Gender: document.getElementById('enr-student-gender').value,
      GradeApplying: document.getElementById('enr-student-grade').value,
      AcademicYear: '2026-2027',
      PreviousSchool: document.getElementById('enr-student-prev').value.trim(),
      ParentFirstName: document.getElementById('enr-parent-first').value.trim(),
      ParentLastName: document.getElementById('enr-parent-last').value.trim(),
      ParentDocId: document.getElementById('enr-parent-doc').value.trim(),
      ParentPhone: document.getElementById('enr-parent-phone').value.trim(),
      ParentEmail: document.getElementById('enr-parent-email').value.trim(),
      ParentAddress: document.getElementById('enr-parent-address').value.trim()
    };

    try {
      const res = await fetch('/api/enrollments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const json = await res.json();
      if (res.ok && json.success) {
        const code = json.data.code;
        alert(`¡Pre-inscripción enviada con éxito!\n\nTu CÓDIGO DE REGISTRO es:\n${code}\n\nConserva este código para consultar el estado de la solicitud y formalizar la entrega de recaudos en secretaría.`);
        document.getElementById('enrollment-form').reset();
        document.getElementById('track-code-input').value = code;
        this.checkEnrollmentStatus();
      } else {
        alert(json.message || 'Error al enviar la solicitud.');
      }
    } catch (err) {
      alert('Error de conexión con el servidor local: ' + err.message);
    }
  },

  async checkEnrollmentStatus() {
    const input = document.getElementById('track-code-input');
    const box = document.getElementById('track-result-box');
    const code = (input.value || '').trim();

    if (!code) {
      alert('Por favor ingresa un código de registro (ej. INS-2026-0001).');
      return;
    }

    try {
      const res = await fetch('/api/enrollments/' + encodeURIComponent(code));
      if (res.ok) {
        const item = await res.json();
        box.style.display = 'block';
        box.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <strong style="color: var(--primary);">${this.escapeHtml(item.Code)}</strong>
            <span class="status-badge status-${(item.Status || 'Pendiente').replace(/\s+/g, '')}">${item.Status}</span>
          </div>
          <p style="font-size: 0.9rem; margin-bottom: 4px;"><strong>Aspirante:</strong> ${this.escapeHtml(item.StudentFirstName)} ${this.escapeHtml(item.StudentLastName)}</p>
          <p style="font-size: 0.85rem; margin-bottom: 4px;"><strong>Grado Solicitado:</strong> ${this.escapeHtml(item.GradeApplying)}</p>
          <p style="font-size: 0.85rem; margin-bottom: 4px;"><strong>Fecha Solicitud:</strong> ${item.SubmittedAt}</p>
          ${item.AdminNotes ? `<div style="margin-top: 8px; padding: 6px 10px; background: #eff6ff; border-radius: 4px; font-size: 0.82rem; color: #1e40af;"><strong>Observación de Secretaría:</strong> ${this.escapeHtml(item.AdminNotes)}</div>` : ''}
        `;
      } else {
        box.style.display = 'block';
        box.innerHTML = `<p style="color: #dc2626; font-size: 0.88rem;">No se encontró ningún registro con el código <strong>${this.escapeHtml(code)}</strong>. Verifica e intenta de nuevo.</p>`;
      }
    } catch (e) {
      alert('Error al consultar estado: ' + e.message);
    }
  },

  // ================= AUTHENTICATION =================
  async checkAuth() {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const json = await res.json();
        if (json.authenticated && json.user) {
          this.currentUser = json.user;
          this.updateNavForUser();
        } else {
          this.currentUser = null;
          this.updateNavForGuest();
        }
      }
    } catch (e) {
      this.currentUser = null;
      this.updateNavForGuest();
    }
  },

  updateNavForUser() {
    const item = document.getElementById('auth-nav-item');
    if (!item || !this.currentUser) return;

    item.innerHTML = `
      <a href="javascript:void(0)" class="btn-admin-login" onclick="app.showTab('admin')" style="background-color: #10b981;">
        ⚙️ Panel (${this.escapeHtml(this.currentUser.username)})
      </a>
    `;
  },

  updateNavForGuest() {
    const item = document.getElementById('auth-nav-item');
    if (!item) return;

    item.innerHTML = `
      <a href="javascript:void(0)" class="btn-admin-login" onclick="app.openLoginModal()">
        🔒 Acceso Personal
      </a>
    `;
  },

  openLoginModal() {
    document.getElementById('login-error').style.display = 'none';
    this.openModal('modal-login');
  },

  async handleLogin(e) {
    e.preventDefault();
    const uname = document.getElementById('login-username').value.trim();
    const pass = document.getElementById('login-password').value;
    const errBox = document.getElementById('login-error');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: uname, password: pass })
      });

      const json = await res.json();
      if (res.ok && json.success) {
        this.currentUser = json.data;
        this.closeModal('modal-login');
        this.updateNavForUser();
        this.showTab('admin');
      } else {
        errBox.textContent = json.message || 'Usuario o contraseña incorrectos.';
        errBox.style.display = 'block';
      }
    } catch (err) {
      errBox.textContent = 'Error de conexión: ' + err.message;
      errBox.style.display = 'block';
    }
  },

  async logout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch { }
    this.currentUser = null;
    this.updateNavForGuest();
    this.showTab('inicio');
  },

  // ================= MODAL HELPERS =================
  openModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.add('active');
  },

  closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.remove('active');
  },

  escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  app.init();
});
