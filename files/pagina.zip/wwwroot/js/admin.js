/**
 * Colegio Divina Providencia - Panel Administrativo
 */

const adminApp = {
  currentSubview: 'dashboard',
  articles: [],
  schedules: [],
  enrollments: [],
  users: [],
  selectedEnrollment: null,

  async init() {
    if (!app.currentUser) return;

    // Render User Header
    const nameEl = document.getElementById('admin-user-fullname');
    if (nameEl) nameEl.textContent = app.currentUser.fullName || app.currentUser.username;

    const roleEl = document.getElementById('admin-user-role');
    if (roleEl) roleEl.textContent = 'Rol: ' + (app.currentUser.role || 'Usuario');

    const avatarEl = document.getElementById('admin-avatar-initials');
    if (avatarEl) {
      const init = (app.currentUser.username || 'AD').substring(0, 2).toUpperCase();
      avatarEl.textContent = init;
    }

    // Role-based visibility
    const usersTab = document.getElementById('admin-users-tab-item');
    if (usersTab) {
      usersTab.style.display = (app.currentUser.role === 'admin') ? 'block' : 'none';
    }

    await this.loadStats();
    await this.loadDashboardEnrollments();
    this.displayLocalNetworkInfo();
  },

  switchTab(subview) {
    this.currentSubview = subview;
    const views = document.querySelectorAll('.admin-subview');
    views.forEach(v => v.style.display = 'none');

    const target = document.getElementById('admin-view-' + subview);
    if (target) target.style.display = 'block';

    const links = document.querySelectorAll('.admin-nav a');
    links.forEach(l => l.classList.remove('active'));

    const active = document.querySelector(`.admin-nav a[onclick*="'${subview}'"]`);
    if (active) active.classList.add('active');

    // Load data based on subview
    if (subview === 'dashboard') {
      this.loadStats();
      this.loadDashboardEnrollments();
    } else if (subview === 'noticias') {
      this.loadArticles();
    } else if (subview === 'horarios') {
      this.loadSchedules();
    } else if (subview === 'inscripciones') {
      this.loadEnrollments();
    } else if (subview === 'institucion') {
      this.loadSettingsForm();
    } else if (subview === 'mantenimiento') {
      this.loadAuditLogs();
    } else if (subview === 'usuarios') {
      this.loadUsers();
    }
  },

  // ================= DASHBOARD & STATS =================
  async loadStats() {
    try {
      const res = await fetch('/api/maintenance/stats');
      if (res.ok) {
        const stats = await res.json();
        document.getElementById('stat-enrollments').textContent = stats.totalEnrollments || 0;
        document.getElementById('stat-pending').textContent = stats.pendingEnrollments || 0;
        document.getElementById('stat-schedules').textContent = stats.totalSchedules || 0;
        document.getElementById('stat-articles').textContent = stats.totalArticles || 0;

        const badge = document.getElementById('admin-pending-badge');
        if (badge) {
          if (stats.pendingEnrollments > 0) {
            badge.textContent = stats.pendingEnrollments;
            badge.style.display = 'inline-block';
          } else {
            badge.style.display = 'none';
          }
        }
      }
    } catch (e) {
      console.warn('Error cargando estadísticas:', e);
    }
  },

  displayLocalNetworkInfo() {
    const box = document.getElementById('admin-local-network-url');
    if (!box) return;

    const host = window.location.host;
    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

    if (isLocalhost) {
      box.innerHTML = `
        <strong>Esta computadora (Servidor):</strong> http://${host}<br>
        <strong>Otras computadoras en red:</strong> Abre la ventana del servidor en la computadora principal para ver la IP exacta (ej: <code>http://192.168.1.X:5000</code>).
      `;
    } else {
      box.innerHTML = `
        <strong>URL activa en la red de la institución:</strong><br>
        <span style="color: #2563eb; font-weight: bold; font-size: 1.1rem;">http://${host}</span><br>
        <span style="font-size: 0.85rem; color: #64748b;">(Cualquier computadora conectada al WiFi o cable puede ingresar con esta dirección)</span>
      `;
    }
  },

  async loadDashboardEnrollments() {
    try {
      const res = await fetch('/api/enrollments');
      if (res.ok) {
        const list = await res.json();
        const table = document.getElementById('admin-dashboard-enrollments-table');
        if (!table) return;

        const top = list.slice(0, 5);
        if (top.length === 0) {
          table.innerHTML = '<tr><td style="text-align: center; color: #64748b; padding: 20px;">No hay registros de pre-inscripción aún.</td></tr>';
          return;
        }

        table.innerHTML = `
          <thead>
            <tr>
              <th>Código</th>
              <th>Aspirante</th>
              <th>Grado</th>
              <th>Representante</th>
              <th>Teléfono</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            ${top.map(e => `
              <tr onclick="adminApp.viewEnrollment('${e.Id}')" style="cursor: pointer;">
                <td><strong>${app.escapeHtml(e.Code)}</strong></td>
                <td>${app.escapeHtml(e.StudentFirstName)} ${app.escapeHtml(e.StudentLastName)}</td>
                <td>${app.escapeHtml(e.GradeApplying)}</td>
                <td>${app.escapeHtml(e.ParentFirstName)} ${app.escapeHtml(e.ParentLastName)}</td>
                <td>${app.escapeHtml(e.ParentPhone)}</td>
                <td><span class="status-badge status-${(e.Status || 'Pendiente').replace(/\s+/g, '')}">${e.Status}</span></td>
              </tr>
            `).join('')}
          </tbody>
        `;
      }
    } catch { }
  },

  // ================= ARTICLES / NEWS CRUD =================
  async loadArticles() {
    try {
      const res = await fetch('/api/articles');
      if (res.ok) {
        this.articles = await res.json();
        this.renderArticlesTable();
      }
    } catch (e) {
      alert('Error cargando artículos: ' + e.message);
    }
  },

  renderArticlesTable() {
    const table = document.getElementById('admin-articles-table');
    if (!table) return;

    if (this.articles.length === 0) {
      table.innerHTML = '<tr><td style="text-align: center; padding: 30px; color: #64748b;">No hay artículos registrados. ¡Crea el primero!</td></tr>';
      return;
    }

    table.innerHTML = `
      <thead>
        <tr>
          <th>Imagen</th>
          <th>Título</th>
          <th>Categoría</th>
          <th>Fecha</th>
          <th>Autor</th>
          <th>Estado</th>
          <th style="text-align: right;">Acciones</th>
        </tr>
      </thead>
      <tbody>
        ${this.articles.map(a => `
          <tr>
            <td style="width: 60px;">
              <img src="${a.ImageUrl || '/images/noticia1.svg'}" alt="" style="width: 50px; height: 35px; object-fit: cover; border-radius: 4px;">
            </td>
            <td><strong>${app.escapeHtml(a.Title)}</strong></td>
            <td><span class="news-badge badge-${(a.Category || 'noticia').toLowerCase()}">${app.formatCategoryName(a.Category)}</span></td>
            <td>${a.PublishedAt || '-'}</td>
            <td>${app.escapeHtml(a.Author || '-')}</td>
            <td>${a.IsPublished ? '<span style="color: #16a34a; font-weight: 600;">Publicado</span>' : '<span style="color: #94a3b8;">Borrador</span>'}</td>
            <td style="text-align: right; white-space: nowrap;">
              <button class="btn-icon" onclick="adminApp.editArticle('${a.Id}')" title="Editar">✏️ Editar</button>
              <button class="btn-icon btn-icon-danger" onclick="adminApp.deleteArticle('${a.Id}')" title="Eliminar">🗑️</button>
            </td>
          </tr>
        `).join('')}
      </tbody>
    `;
  },

  openArticleModal(article = null) {
    document.getElementById('edit-art-id').value = article ? article.Id : '';
    document.getElementById('edit-art-title').value = article ? article.Title : '';
    document.getElementById('edit-art-category').value = article ? article.Category : 'noticia';
    document.getElementById('edit-art-summary').value = article ? article.Summary : '';
    document.getElementById('edit-art-content').value = article ? article.Content : '';
    document.getElementById('edit-art-date').value = article ? article.PublishedAt : new Date().toISOString().split('T')[0];
    document.getElementById('edit-art-published').checked = article ? article.IsPublished : true;
    document.getElementById('edit-art-featured').checked = article ? article.IsFeatured : false;
    document.getElementById('edit-art-image-url').value = article ? (article.ImageUrl || '') : '';
    document.getElementById('edit-art-file').value = '';

    const preview = document.getElementById('art-img-preview');
    const previewBox = document.getElementById('art-img-preview-box');
    if (article && article.ImageUrl) {
      preview.src = article.ImageUrl;
      previewBox.style.display = 'block';
    } else {
      previewBox.style.display = 'none';
    }

    document.getElementById('modal-article-form-title').textContent = article ? 'Editar Artículo' : 'Publicar Artículo o Evento';
    app.openModal('modal-edit-article');
  },

  editArticle(id) {
    const article = this.articles.find(a => a.Id === id);
    if (article) this.openArticleModal(article);
  },

  previewArticleImage(input) {
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        document.getElementById('art-img-preview').src = e.target.result;
        document.getElementById('art-img-preview-box').style.display = 'block';
        document.getElementById('edit-art-image-url').value = e.target.result; // store data base64
      };
      reader.readAsDataURL(file);
    }
  },

  async saveArticle(e) {
    e.preventDefault();

    const id = document.getElementById('edit-art-id').value;
    let imageUrl = document.getElementById('edit-art-image-url').value;

    // Check if new local image was selected (base64)
    if (imageUrl && imageUrl.startsWith('data:image')) {
      try {
        const uploadRes = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data: imageUrl })
        });
        const uploadJson = await uploadRes.json();
        if (uploadRes.ok && uploadJson.success) {
          imageUrl = uploadJson.data.url;
        }
      } catch (err) {
        alert('Error subiendo imagen al servidor local: ' + err.message);
        return;
      }
    }

    const payload = {
      Title: document.getElementById('edit-art-title').value.trim(),
      Category: document.getElementById('edit-art-category').value,
      Summary: document.getElementById('edit-art-summary').value.trim(),
      Content: document.getElementById('edit-art-content').value.trim(),
      ImageUrl: imageUrl || '/images/noticia1.svg',
      PublishedAt: document.getElementById('edit-art-date').value,
      IsPublished: document.getElementById('edit-art-published').checked,
      IsFeatured: document.getElementById('edit-art-featured').checked
    };

    try {
      const url = id ? '/api/articles/' + id : '/api/articles';
      const method = id ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const json = await res.json();
      if (res.ok && json.success) {
        app.closeModal('modal-edit-article');
        await this.loadArticles();
        await app.loadArticles();
      } else {
        alert(json.message || 'Error guardando artículo.');
      }
    } catch (err) {
      alert('Error en servidor: ' + err.message);
    }
  },

  async deleteArticle(id) {
    if (!confirm('¿Estás seguro de eliminar este artículo?')) return;

    try {
      const res = await fetch('/api/articles/' + id, { method: 'DELETE' });
      if (res.ok) {
        await this.loadArticles();
        await app.loadArticles();
      }
    } catch (e) {
      alert('Error eliminando: ' + e.message);
    }
  },

  // ================= SCHEDULES CRUD =================
  async loadSchedules() {
    try {
      const res = await fetch('/api/schedules');
      if (res.ok) {
        this.schedules = await res.json();
        this.renderSchedulesTable();
      }
    } catch (e) {
      alert('Error cargando horarios: ' + e.message);
    }
  },

  renderSchedulesTable() {
    const table = document.getElementById('admin-schedules-table');
    if (!table) return;

    if (this.schedules.length === 0) {
      table.innerHTML = '<tr><td style="text-align: center; padding: 30px; color: #64748b;">No hay horarios registrados. ¡Crea uno nuevo!</td></tr>';
      return;
    }

    table.innerHTML = `
      <thead>
        <tr>
          <th>Nivel</th>
          <th>Grado / Año</th>
          <th>Sección</th>
          <th>Turno</th>
          <th>Aula</th>
          <th>Coordinador(a)</th>
          <th>Última Actualización</th>
          <th style="text-align: right;">Acciones</th>
        </tr>
      </thead>
      <tbody>
        ${this.schedules.map(s => `
          <tr>
            <td><span class="section-tag" style="padding: 2px 8px; font-size: 0.72rem;">${s.Level || 'N/A'}</span></td>
            <td><strong>${app.escapeHtml(s.Grade)}</strong></td>
            <td><span class="room-badge">${s.Section}</span></td>
            <td>${s.Shift || 'Mañana'}</td>
            <td>${app.escapeHtml(s.Classroom || '-')}</td>
            <td>${app.escapeHtml(s.Coordinator || '-')}</td>
            <td><small>${s.UpdatedAt || '-'}</small></td>
            <td style="text-align: right; white-space: nowrap;">
              <button class="btn-icon" onclick="adminApp.previewScheduleInPortal('${s.Id}')" title="Ver">👁️ Ver</button>
              <button class="btn-icon" onclick="adminApp.editSchedule('${s.Id}')" title="Editar">✏️ Editar</button>
              <button class="btn-icon btn-icon-danger" onclick="adminApp.deleteSchedule('${s.Id}')" title="Eliminar">🗑️</button>
            </td>
          </tr>
        `).join('')}
      </tbody>
    `;
  },

  previewScheduleInPortal(id) {
    const s = this.schedules.find(x => x.Id === id);
    if (s) {
      app.renderSchedule(s);
      app.showTab('horarios');
    }
  },

  openScheduleModal(sch = null) {
    document.getElementById('edit-sched-id').value = sch ? sch.Id : '';
    document.getElementById('edit-sched-level').value = sch ? sch.Level : 'Bachillerato';
    document.getElementById('edit-sched-grade').value = sch ? sch.Grade : '';
    document.getElementById('edit-sched-section').value = sch ? sch.Section : 'A';
    document.getElementById('edit-sched-shift').value = sch ? sch.Shift : 'Mañana';
    document.getElementById('edit-sched-classroom').value = sch ? (sch.Classroom || '') : '';
    document.getElementById('edit-sched-coordinator').value = sch ? (sch.Coordinator || '') : '';

    this.renderDayEditors(sch ? sch.Days : null);
    document.getElementById('modal-sched-form-title').textContent = sch ? 'Editar Horario Académico' : 'Crear Nuevo Horario';
    app.openModal('modal-edit-schedule');
  },

  editSchedule(id) {
    const sch = this.schedules.find(s => s.Id === id);
    if (sch) this.openScheduleModal(sch);
  },

  renderDayEditors(existingDays) {
    const wrap = document.getElementById('schedule-builder-days-wrap');
    if (!wrap) return;

    const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
    const defaultTimes = [
      '07:00 - 07:45',
      '07:45 - 08:30',
      '08:30 - 09:15',
      '09:15 - 09:45',
      '09:45 - 10:30',
      '10:30 - 11:15',
      '11:15 - 12:00'
    ];

    wrap.innerHTML = days.map((dayName, dIdx) => {
      const dayData = (existingDays || []).find(d => d.Day && d.Day.toLowerCase() === dayName.toLowerCase());
      const periods = dayData ? dayData.Periods : defaultTimes.map(t => ({
        Time: t,
        Subject: t.includes('09:15') ? 'RECESO' : '',
        Teacher: '',
        Room: ''
      }));

      return `
        <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 14px; margin-bottom: 14px;">
          <h5 style="color: var(--primary); margin-bottom: 10px; font-size: 1rem;">📅 ${dayName}</h5>
          <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem;" id="day-table-${dIdx}">
            <thead>
              <tr style="text-align: left; color: #475569;">
                <th style="padding: 4px; width: 140px;">Horario</th>
                <th style="padding: 4px;">Materia / Asignatura</th>
                <th style="padding: 4px;">Profesor(a)</th>
                <th style="padding: 4px; width: 110px;">Aula</th>
              </tr>
            </thead>
            <tbody>
              ${periods.map((p, pIdx) => `
                <tr>
                  <td style="padding: 4px;">
                    <input type="text" class="form-control" style="padding: 4px 8px; font-size: 0.82rem;" value="${app.escapeHtml(p.Time)}" data-day="${dayName}" data-field="Time">
                  </td>
                  <td style="padding: 4px;">
                    <input type="text" class="form-control" style="padding: 4px 8px; font-size: 0.82rem;" value="${app.escapeHtml(p.Subject)}" placeholder="Materia" data-day="${dayName}" data-field="Subject">
                  </td>
                  <td style="padding: 4px;">
                    <input type="text" class="form-control" style="padding: 4px 8px; font-size: 0.82rem;" value="${app.escapeHtml(p.Teacher)}" placeholder="Profesor" data-day="${dayName}" data-field="Teacher">
                  </td>
                  <td style="padding: 4px;">
                    <input type="text" class="form-control" style="padding: 4px 8px; font-size: 0.82rem;" value="${app.escapeHtml(p.Room)}" placeholder="Aula" data-day="${dayName}" data-field="Room">
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }).join('');
  },

  async saveSchedule(e) {
    e.preventDefault();

    const id = document.getElementById('edit-sched-id').value;
    const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];

    // Collect days from the editor tables
    const collectedDays = [];
    days.forEach((dayName, dIdx) => {
      const table = document.getElementById('day-table-' + dIdx);
      if (!table) return;

      const dayObj = { Day: dayName, Periods: [] };
      const rows = table.querySelectorAll('tbody tr');
      rows.forEach(row => {
        const time = row.querySelector('[data-field="Time"]').value.trim();
        const subject = row.querySelector('[data-field="Subject"]').value.trim();
        const teacher = row.querySelector('[data-field="Teacher"]').value.trim();
        const room = row.querySelector('[data-field="Room"]').value.trim();

        if (time || subject) {
          dayObj.Periods.push({ Time: time, Subject: subject, Teacher: teacher, Room: room });
        }
      });
      collectedDays.push(dayObj);
    });

    const payload = {
      Level: document.getElementById('edit-sched-level').value,
      Grade: document.getElementById('edit-sched-grade').value.trim(),
      Section: document.getElementById('edit-sched-section').value,
      Shift: document.getElementById('edit-sched-shift').value,
      Classroom: document.getElementById('edit-sched-classroom').value.trim(),
      Coordinator: document.getElementById('edit-sched-coordinator').value.trim(),
      SchoolYear: '2026-2027',
      Days: collectedDays
    };

    try {
      const url = id ? '/api/schedules/' + id : '/api/schedules';
      const method = id ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const json = await res.json();
      if (res.ok && json.success) {
        app.closeModal('modal-edit-schedule');
        await this.loadSchedules();
        await app.loadSchedules();
      } else {
        alert(json.message || 'Error guardando horario.');
      }
    } catch (err) {
      alert('Error en servidor: ' + err.message);
    }
  },

  async deleteSchedule(id) {
    if (!confirm('¿Deseas eliminar este horario?')) return;

    try {
      const res = await fetch('/api/schedules/' + id, { method: 'DELETE' });
      if (res.ok) {
        await this.loadSchedules();
        await app.loadSchedules();
      }
    } catch (e) {
      alert('Error eliminando horario: ' + e.message);
    }
  },

  // ================= ENROLLMENTS =================
  async loadEnrollments() {
    try {
      const res = await fetch('/api/enrollments');
      if (res.ok) {
        this.enrollments = await res.json();
        this.renderEnrollmentsTable();
      }
    } catch (e) {
      alert('Error cargando inscripciones: ' + e.message);
    }
  },

  renderEnrollmentsTable() {
    const table = document.getElementById('admin-enrollments-table');
    if (!table) return;

    const filterStatus = document.getElementById('admin-filter-enr-status').value;
    let list = this.enrollments;
    if (filterStatus) {
      list = list.filter(e => e.Status === filterStatus);
    }

    if (list.length === 0) {
      table.innerHTML = '<tr><td style="text-align: center; padding: 30px; color: #64748b;">No se encontraron solicitudes con este filtro.</td></tr>';
      return;
    }

    table.innerHTML = `
      <thead>
        <tr>
          <th>Código</th>
          <th>Aspirante</th>
          <th>C.I. / Doc</th>
          <th>Grado</th>
          <th>Representante</th>
          <th>Teléfono</th>
          <th>Fecha Registro</th>
          <th>Estado</th>
          <th style="text-align: right;">Acciones</th>
        </tr>
      </thead>
      <tbody>
        ${list.map(e => `
          <tr>
            <td><strong>${app.escapeHtml(e.Code)}</strong></td>
            <td>${app.escapeHtml(e.StudentFirstName)} ${app.escapeHtml(e.StudentLastName)}</td>
            <td><small>${app.escapeHtml(e.StudentDocId || 'Sin doc')}</small></td>
            <td>${app.escapeHtml(e.GradeApplying)}</td>
            <td>${app.escapeHtml(e.ParentFirstName)} ${app.escapeHtml(e.ParentLastName)}</td>
            <td>${app.escapeHtml(e.ParentPhone)}</td>
            <td><small>${e.SubmittedAt}</small></td>
            <td><span class="status-badge status-${(e.Status || 'Pendiente').replace(/\s+/g, '')}">${e.Status}</span></td>
            <td style="text-align: right; white-space: nowrap;">
              <button class="btn-icon" onclick="adminApp.viewEnrollment('${e.Id}')" title="Ver Ficha">👁️ Ficha</button>
              <button class="btn-icon btn-icon-danger" onclick="adminApp.deleteEnrollment('${e.Id}')" title="Eliminar">🗑️</button>
            </td>
          </tr>
        `).join('')}
      </tbody>
    `;
  },

  viewEnrollment(id) {
    const enr = (this.enrollments.length > 0 ? this.enrollments : []).find(e => e.Id === id || e.Code === id);
    if (!enr) return;

    this.selectedEnrollment = enr;
    const box = document.getElementById('detail-enrollment-content');
    if (!box) return;

    box.innerHTML = `
      <div style="background: #eff6ff; padding: 14px; border-radius: var(--radius-sm); border: 1px solid #bfdbfe; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h4 style="color: var(--primary); font-size: 1.1rem;">Código: ${app.escapeHtml(enr.Code)}</h4>
          <p style="font-size: 0.85rem; color: #1e40af;">Fecha de Solicitud: ${enr.SubmittedAt}</p>
        </div>
        <div>
          <select id="enr-update-status-select" class="form-select" onchange="adminApp.updateEnrollmentStatus('${enr.Id}', this.value)" style="font-weight: bold;">
            <option value="Pendiente" ${enr.Status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
            <option value="Aprobado" ${enr.Status === 'Aprobado' ? 'selected' : ''}>Aprobado</option>
            <option value="En Revisión" ${enr.Status === 'En Revisión' ? 'selected' : ''}>En Revisión</option>
            <option value="Rechazado" ${enr.Status === 'Rechazado' ? 'selected' : ''}>Rechazado</option>
          </select>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
        <div style="background: #ffffff; padding: 14px; border: 1px solid var(--border); border-radius: 6px;">
          <h5 style="color: var(--secondary); margin-bottom: 10px; border-bottom: 1px solid var(--border); padding-bottom: 4px;">Datos del Aspirante</h5>
          <p><strong>Nombres:</strong> ${app.escapeHtml(enr.StudentFirstName)} ${app.escapeHtml(enr.StudentLastName)}</p>
          <p><strong>Identificación:</strong> ${app.escapeHtml(enr.StudentDocId || 'Pendiente por consignar')}</p>
          <p><strong>Nacimiento:</strong> ${enr.BirthDate || '-'}</p>
          <p><strong>Género:</strong> ${enr.Gender || '-'}</p>
          <p><strong>Grado:</strong> ${app.escapeHtml(enr.GradeApplying)}</p>
          <p><strong>Plantel Anterior:</strong> ${app.escapeHtml(enr.PreviousSchool || 'No especificado')}</p>
        </div>

        <div style="background: #ffffff; padding: 14px; border: 1px solid var(--border); border-radius: 6px;">
          <h5 style="color: var(--secondary); margin-bottom: 10px; border-bottom: 1px solid var(--border); padding-bottom: 4px;">Datos del Representante</h5>
          <p><strong>Nombres:</strong> ${app.escapeHtml(enr.ParentFirstName)} ${app.escapeHtml(enr.ParentLastName)}</p>
          <p><strong>Cédula:</strong> ${app.escapeHtml(enr.ParentDocId)}</p>
          <p><strong>Teléfono:</strong> ${app.escapeHtml(enr.ParentPhone)}</p>
          <p><strong>Correo:</strong> ${app.escapeHtml(enr.ParentEmail)}</p>
          <p><strong>Dirección:</strong> ${app.escapeHtml(enr.ParentAddress || '-')}</p>
        </div>
      </div>

      <div class="form-group">
        <label>Notas Internas de Secretaría</label>
        <textarea id="enr-admin-notes" class="form-control" rows="2" placeholder="Observaciones de los documentos o notas consignadas...">${app.escapeHtml(enr.AdminNotes || '')}</textarea>
        <button class="btn btn-primary" onclick="adminApp.saveEnrollmentNotes('${enr.Id}')" style="margin-top: 8px; align-self: flex-start; border: 1px solid var(--border);">
          Guardar Nota
        </button>
      </div>
    `;

    app.openModal('modal-detail-enrollment');
  },

  async updateEnrollmentStatus(id, newStatus) {
    try {
      const res = await fetch('/api/enrollments/' + id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ Status: newStatus })
      });
      if (res.ok) {
        await this.loadEnrollments();
        await this.loadStats();
      }
    } catch (e) {
      alert('Error actualizando estado: ' + e.message);
    }
  },

  async saveEnrollmentNotes(id) {
    const notes = document.getElementById('enr-admin-notes').value.trim();
    try {
      const res = await fetch('/api/enrollments/' + id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ AdminNotes: notes })
      });
      if (res.ok) {
        alert('Nota guardada correctamente.');
        await this.loadEnrollments();
      }
    } catch (e) {
      alert('Error guardando nota: ' + e.message);
    }
  },

  async deleteEnrollment(id) {
    if (!confirm('¿Deseas eliminar este registro de pre-inscripción?')) return;
    try {
      const res = await fetch('/api/enrollments/' + id, { method: 'DELETE' });
      if (res.ok) {
        await this.loadEnrollments();
        await this.loadStats();
      }
    } catch (e) {
      alert('Error eliminando: ' + e.message);
    }
  },

  printEnrollmentReceipt() {
    if (!this.selectedEnrollment) return;
    const e = this.selectedEnrollment;
    const win = window.open('', '_blank');
    win.document.write(`
      <!DOCTYPE html>
      <html lang="es">
      <head>
        <title>Comprobante de Pre-inscripción - ${e.Code}</title>
        <style>
          body { font-family: sans-serif; padding: 30px; color: #000; }
          .header { text-align: center; border-bottom: 2px solid #1e3a8a; padding-bottom: 15px; margin-bottom: 20px; }
          .code-box { background: #f1f5f9; border: 2px dashed #1e3a8a; padding: 12px; text-align: center; font-size: 1.4rem; font-weight: bold; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
          th { background: #1e3a8a; color: #fff; }
          .sigs { display: flex; justify-content: space-around; margin-top: 60px; }
          .sig-line { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 6px; font-size: 0.85rem; }
        </style>
      </head>
      <body>
        <div class="header">
          <h2>COLEGIO DIVINA PROVIDENCIA</h2>
          <p>COMPROBANTE OFICIAL DE PRE-INSCRIPCIÓN DIGITAL</p>
        </div>
        <div class="code-box">CÓDIGO: ${e.Code}</div>
        <table>
          <tr><th colspan="2">1. DATOS DEL ASPIRANTE</th></tr>
          <tr><td><strong>Nombres y Apellidos:</strong></td><td>${e.StudentFirstName} ${e.StudentLastName}</td></tr>
          <tr><td><strong>Documento de Identidad:</strong></td><td>${e.StudentDocId || 'Pendiente'}</td></tr>
          <tr><td><strong>Grado Solicitado:</strong></td><td>${e.GradeApplying}</td></tr>
          <tr><td><strong>Fecha de Nacimiento:</strong></td><td>${e.BirthDate || '-'}</td></tr>
        </table>
        <table>
          <tr><th colspan="2">2. DATOS DEL REPRESENTANTE LEGAL</th></tr>
          <tr><td><strong>Representante:</strong></td><td>${e.ParentFirstName} ${e.ParentLastName}</td></tr>
          <tr><td><strong>Cédula:</strong></td><td>${e.ParentDocId}</td></tr>
          <tr><td><strong>Teléfono:</strong></td><td>${e.ParentPhone}</td></tr>
          <tr><td><strong>Correo Electrónico:</strong></td><td>${e.ParentEmail}</td></tr>
          <tr><td><strong>Estado Actual:</strong></td><td>${e.Status}</td></tr>
        </table>
        <div class="sigs">
          <div class="sig-line">Firma del Representante</div>
          <div class="sig-line">Sello de Secretaría</div>
        </div>
        <script>window.onload = function() { window.print(); };</script>
      </body>
      </html>
    `);
    win.document.close();
  },

  // ================= SETTINGS FORM =================
  async loadSettingsForm() {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const s = await res.json();
        document.getElementById('setting-school-name').value = s.SchoolName || '';
        document.getElementById('setting-slogan').value = s.Slogan || '';
        document.getElementById('setting-principal').value = s.PrincipalName || '';
        document.getElementById('setting-enrollment-open').value = s.EnrollmentOpen ? 'true' : 'false';
        document.getElementById('setting-enrollment-notice').value = s.EnrollmentNotice || '';
        document.getElementById('setting-mission').value = s.Mission || '';
        document.getElementById('setting-vision').value = s.Vision || '';
        document.getElementById('setting-history').value = s.History || '';
        document.getElementById('setting-values').value = s.Values || '';
        document.getElementById('setting-address').value = s.Address || '';
        document.getElementById('setting-phone').value = s.Phone || '';
        document.getElementById('setting-email').value = s.Email || '';
        document.getElementById('setting-hours').value = s.OfficeHours || '';
      }
    } catch { }
  },

  async saveSettings(e) {
    e.preventDefault();

    const payload = {
      SchoolName: document.getElementById('setting-school-name').value.trim(),
      Slogan: document.getElementById('setting-slogan').value.trim(),
      PrincipalName: document.getElementById('setting-principal').value.trim(),
      EnrollmentOpen: document.getElementById('setting-enrollment-open').value === 'true',
      EnrollmentNotice: document.getElementById('setting-enrollment-notice').value.trim(),
      Mission: document.getElementById('setting-mission').value.trim(),
      Vision: document.getElementById('setting-vision').value.trim(),
      History: document.getElementById('setting-history').value.trim(),
      Values: document.getElementById('setting-values').value.trim(),
      Address: document.getElementById('setting-address').value.trim(),
      Phone: document.getElementById('setting-phone').value.trim(),
      Email: document.getElementById('setting-email').value.trim(),
      OfficeHours: document.getElementById('setting-hours').value.trim()
    };

    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const json = await res.json();
      if (res.ok && json.success) {
        alert('Información institucional actualizada exitosamente.');
        await app.loadSettings();
      } else {
        alert(json.message || 'Error guardando configuración.');
      }
    } catch (err) {
      alert('Error de conexión: ' + err.message);
    }
  },

  // ================= MAINTENANCE & BACKUPS =================
  async createQuickBackup() {
    try {
      const res = await fetch('/api/maintenance/backup', { method: 'POST' });
      const json = await res.json();
      if (res.ok && json.success) {
        alert('¡Copia de seguridad local generada con éxito!\nGuardada en: data/backups/' + json.data.file);
        if (this.currentSubview === 'mantenimiento') this.loadAuditLogs();
      } else {
        alert(json.message || 'Error creando copia.');
      }
    } catch (e) {
      alert('Error: ' + e.message);
    }
  },

  downloadBackupFile() {
    window.location.href = '/api/maintenance/backup';
  },

  async restoreBackupFile() {
    const input = document.getElementById('restore-file-input');
    if (!input.files || !input.files[0]) {
      alert('Por favor selecciona un archivo .json de respaldo primero.');
      return;
    }

    if (!confirm('¡ATENCIÓN! Restaurar una copia reemplazará los datos actuales por los del archivo. ¿Deseas continuar?')) return;

    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const jsonContent = e.target.result;
        const res = await fetch('/api/maintenance/restore', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jsonContent: jsonContent })
        });
        const json = await res.json();
        if (res.ok && json.success) {
          alert('¡Base de datos restaurada correctamente!');
          window.location.reload();
        } else {
          alert(json.message || 'Error restaurando datos.');
        }
      } catch (err) {
        alert('Error procesando archivo: ' + err.message);
      }
    };
    reader.readAsText(file);
  },

  async loadAuditLogs() {
    try {
      const res = await fetch('/api/maintenance/audit');
      if (res.ok) {
        const logs = await res.json();
        const table = document.getElementById('admin-audit-table');
        if (!table) return;

        if (logs.length === 0) {
          table.innerHTML = '<tr><td style="text-align: center; padding: 20px; color: #64748b;">No hay registros de auditoría aún.</td></tr>';
          return;
        }

        table.innerHTML = `
          <thead>
            <tr>
              <th>Fecha y Hora</th>
              <th>Usuario</th>
              <th>Acción Realizada</th>
              <th>Detalles</th>
            </tr>
          </thead>
          <tbody>
            ${logs.map(l => `
              <tr>
                <td style="white-space: nowrap;"><small>${l.Timestamp}</small></td>
                <td><strong>${app.escapeHtml(l.User)}</strong></td>
                <td><span class="room-badge">${app.escapeHtml(l.Action)}</span></td>
                <td><small style="color: #475569;">${app.escapeHtml(l.Details)}</small></td>
              </tr>
            `).join('')}
          </tbody>
        `;
      }
    } catch { }
  },

  // ================= USERS MANAGEMENT =================
  async loadUsers() {
    try {
      const res = await fetch('/api/users');
      if (res.ok) {
        this.users = await res.json();
        this.renderUsersTable();
      }
    } catch (e) {
      alert('Error cargando usuarios: ' + e.message);
    }
  },

  renderUsersTable() {
    const table = document.getElementById('admin-users-table');
    if (!table) return;

    table.innerHTML = `
      <thead>
        <tr>
          <th>Usuario</th>
          <th>Nombre Completo</th>
          <th>Rol</th>
          <th>Fecha Creación</th>
        </tr>
      </thead>
      <tbody>
        ${this.users.map(u => `
          <tr>
            <td><strong>${app.escapeHtml(u.username)}</strong></td>
            <td>${app.escapeHtml(u.fullName)}</td>
            <td><span class="news-badge badge-${u.role === 'admin' ? 'noticia' : 'academico'}">${u.role.toUpperCase()}</span></td>
            <td><small>${u.createdAt || '-'}</small></td>
          </tr>
        `).join('')}
      </tbody>
    `;
  },

  openUserModal() {
    document.getElementById('form-create-user').reset();
    app.openModal('modal-create-user');
  },

  async createUser(e) {
    e.preventDefault();

    const payload = {
      username: document.getElementById('new-user-username').value.trim(),
      fullName: document.getElementById('new-user-fullname').value.trim(),
      role: document.getElementById('new-user-role').value,
      password: document.getElementById('new-user-password').value
    };

    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const json = await res.json();
      if (res.ok && json.success) {
        app.closeModal('modal-create-user');
        alert('Usuario creado exitosamente.');
        await this.loadUsers();
      } else {
        alert(json.message || 'Error creando usuario.');
      }
    } catch (err) {
      alert('Error de red: ' + err.message);
    }
  }
};
