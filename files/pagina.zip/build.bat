@echo off
chcp 65001 > nul
echo ===================================================
echo     Compilando Servidor Colegio Divina Providencia
echo ===================================================

set CSC_PATH=""
if exist "E:\visual\MSBuild\Current\Bin\Roslyn\csc.exe" (
    set CSC_PATH="E:\visual\MSBuild\Current\Bin\Roslyn\csc.exe"
) else if exist "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe" (
    set CSC_PATH="C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
)

if %CSC_PATH%=="" (
    echo [ERROR] No se encontró el compilador C# (csc.exe).
    pause
    exit /b 1
)

echo Compilando con %CSC_PATH%...
%CSC_PATH% /target:exe /out:ColegioServidor.exe /r:System.Web.Extensions.dll src\Models.cs src\Auth.cs src\Database.cs src\ApiHandler.cs src\Server.cs src\Program.cs

if %ERRORLEVEL% EQU 0 (
    echo [ÉXITO] ColegioServidor.exe generado correctamente.
) else (
    echo [ERROR] Ocurrió un error durante la compilación.
)
pause
