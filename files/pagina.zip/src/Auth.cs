using System;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;

namespace DivinaProvidencia
{
    public class UserSession
    {
        public string Token { get; set; }
        public string UserId { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
        public DateTime ExpiresAt { get; set; }
    }

    public static class AuthManager
    {
        private static readonly ConcurrentDictionary<string, UserSession> _sessions = new ConcurrentDictionary<string, UserSession>();

        public static string GenerateSalt()
        {
            byte[] bytes = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(bytes);
            }
            return Convert.ToBase64String(bytes);
        }

        public static string HashPassword(string password, string salt)
        {
            using (var sha = SHA256.Create())
            {
                byte[] combined = Encoding.UTF8.GetBytes(password + ":" + salt);
                byte[] hash = sha.ComputeHash(combined);
                return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }
        }

        public static bool VerifyPassword(string password, string salt, string hash)
        {
            string computed = HashPassword(password, salt);
            return string.Equals(computed, hash, StringComparison.OrdinalIgnoreCase);
        }

        public static UserSession CreateSession(User user)
        {
            string token = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N");
            var session = new UserSession
            {
                Token = token,
                UserId = user.Id,
                Username = user.Username,
                FullName = user.FullName,
                Role = user.Role,
                ExpiresAt = DateTime.UtcNow.AddHours(12) // 12-hour session
            };
            _sessions[token] = session;
            return session;
        }

        public static UserSession ValidateToken(string token)
        {
            if (string.IsNullOrEmpty(token)) return null;

            UserSession session;
            if (_sessions.TryGetValue(token, out session))
            {
                if (DateTime.UtcNow > session.ExpiresAt)
                {
                    _sessions.TryRemove(token, out _);
                    return null;
                }
                // Slide expiry on activity
                session.ExpiresAt = DateTime.UtcNow.AddHours(12);
                return session;
            }
            return null;
        }

        public static void RevokeSession(string token)
        {
            if (!string.IsNullOrEmpty(token))
            {
                _sessions.TryRemove(token, out _);
            }
        }
    }
}
