using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace DivinaProvidencia
{
    public class ApiResponse
    {
        public int StatusCode { get; set; }
        public string ContentType { get; set; }
        public byte[] Body { get; set; }
        public Dictionary<string, string> Headers { get; set; }

        public ApiResponse()
        {
            StatusCode = 200;
            ContentType = "application/json; charset=utf-8";
            Headers = new Dictionary<string, string>();
        }

        public static ApiResponse Json(object data, int status = 200)
        {
            var serializer = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            string json = serializer.Serialize(data);
            return new ApiResponse
            {
                StatusCode = status,
                ContentType = "application/json; charset=utf-8",
                Body = Encoding.UTF8.GetBytes(json)
            };
        }

        public static ApiResponse Error(string message, int status = 400)
        {
            return Json(new { success = false, message = message }, status);
        }

        public static ApiResponse Success(string message, object extra = null)
        {
            var dict = new Dictionary<string, object>
            {
                { "success", true },
                { "message", message }
            };
            if (extra != null)
            {
                dict["data"] = extra;
            }
            return Json(dict);
        }
    }

    public class ApiHandler
    {
        private readonly DatabaseService _dbService;
        private readonly string _baseDir;
        private readonly JavaScriptSerializer _serializer;

        public ApiHandler(DatabaseService dbService, string baseDir)
        {
            _dbService = dbService;
            _baseDir = baseDir;
            _serializer = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        }

        public ApiResponse Handle(string method, string path, Dictionary<string, string> query, string bodyStr, UserSession session)
        {
            try
            {
                // ================= AUTH ENDPOINTS =================
                if (path == "/api/auth/login" && method == "POST")
                {
                    return Login(bodyStr);
                }

                if (path == "/api/auth/logout" && method == "POST")
                {
                    if (session != null) AuthManager.RevokeSession(session.Token);
                    var resp = ApiResponse.Success("Sesión cerrada correctamente");
                    resp.Headers["Set-Cookie"] = "session_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly";
                    return resp;
                }

                if (path == "/api/auth/me" && method == "GET")
                {
                    if (session == null)
                    {
                        return ApiResponse.Json(new { authenticated = false });
                    }
                    return ApiResponse.Json(new
                    {
                        authenticated = true,
                        user = new
                        {
                            username = session.Username,
                            fullName = session.FullName,
                            role = session.Role
                        }
                    });
                }

                // ================= PUBLIC / INSTITUTION SETTINGS =================
                if (path == "/api/settings")
                {
                    if (method == "GET")
                    {
                        var db = _dbService.Get();
                        return ApiResponse.Json(db.Settings);
                    }
                    if (method == "PUT")
                    {
                        if (session == null || session.Role != "admin") return ApiResponse.Error("Acceso no autorizado", 403);
                        var updated = _serializer.Deserialize<InstitutionSettings>(bodyStr);
                        if (updated == null) return ApiResponse.Error("Datos inválidos");

                        var db = _dbService.Get();
                        db.Settings = updated;
                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Configuración Institucional Actualizada", "Se actualizaron los datos del colegio.");
                        return ApiResponse.Success("Información institucional actualizada con éxito", db.Settings);
                    }
                }

                // ================= ARTICLES / NEWS =================
                if (path == "/api/articles")
                {
                    if (method == "GET")
                    {
                        var db = _dbService.Get();
                        // If public, show only published articles
                        var articles = (session != null)
                            ? db.Articles.OrderByDescending(a => a.PublishedAt).ToList()
                            : db.Articles.Where(a => a.IsPublished).OrderByDescending(a => a.PublishedAt).ToList();
                        return ApiResponse.Json(articles);
                    }

                    if (method == "POST")
                    {
                        if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                        var article = _serializer.Deserialize<Article>(bodyStr);
                        if (article == null || string.IsNullOrEmpty(article.Title)) return ApiResponse.Error("El título es obligatorio");

                        article.Id = Guid.NewGuid().ToString("N");
                        if (string.IsNullOrEmpty(article.PublishedAt))
                            article.PublishedAt = DateTime.Now.ToString("yyyy-MM-dd");
                        if (string.IsNullOrEmpty(article.Author))
                            article.Author = session.FullName;

                        var db = _dbService.Get();
                        db.Articles.Insert(0, article);
                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Artículo Publicado", "Título: " + article.Title);
                        return ApiResponse.Success("Artículo creado satisfactoriamente", article);
                    }
                }

                if (path.StartsWith("/api/articles/"))
                {
                    string id = path.Substring("/api/articles/".Length).Trim();
                    var db = _dbService.Get();
                    var existing = db.Articles.FirstOrDefault(a => a.Id == id);
                    if (existing == null) return ApiResponse.Error("Artículo no encontrado", 404);

                    if (method == "GET")
                    {
                        return ApiResponse.Json(existing);
                    }

                    if (method == "PUT")
                    {
                        if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                        var updated = _serializer.Deserialize<Article>(bodyStr);
                        if (updated == null) return ApiResponse.Error("Datos inválidos");

                        existing.Title = updated.Title;
                        existing.Summary = updated.Summary;
                        existing.Content = updated.Content;
                        existing.Category = updated.Category;
                        existing.ImageUrl = updated.ImageUrl;
                        existing.IsFeatured = updated.IsFeatured;
                        existing.IsPublished = updated.IsPublished;
                        if (!string.IsNullOrEmpty(updated.PublishedAt))
                            existing.PublishedAt = updated.PublishedAt;

                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Artículo Modificado", "Título: " + existing.Title);
                        return ApiResponse.Success("Artículo actualizado satisfactoriamente", existing);
                    }

                    if (method == "DELETE")
                    {
                        if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                        db.Articles.Remove(existing);
                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Artículo Eliminado", "Título: " + existing.Title);
                        return ApiResponse.Success("Artículo eliminado correctamente");
                    }
                }

                // ================= IMAGE UPLOAD =================
                if (path == "/api/upload" && method == "POST")
                {
                    if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                    return UploadImage(bodyStr);
                }

                // ================= SCHEDULES =================
                if (path == "/api/schedules")
                {
                    if (method == "GET")
                    {
                        var db = _dbService.Get();
                        var queryGrade = query.ContainsKey("grade") ? query["grade"] : null;
                        var queryLevel = query.ContainsKey("level") ? query["level"] : null;
                        var querySection = query.ContainsKey("section") ? query["section"] : null;

                        var list = db.Schedules.AsEnumerable();
                        if (!string.IsNullOrEmpty(queryGrade))
                            list = list.Where(s => s.Grade.IndexOf(queryGrade, StringComparison.OrdinalIgnoreCase) >= 0);
                        if (!string.IsNullOrEmpty(queryLevel))
                            list = list.Where(s => s.Level.IndexOf(queryLevel, StringComparison.OrdinalIgnoreCase) >= 0);
                        if (!string.IsNullOrEmpty(querySection))
                            list = list.Where(s => string.Equals(s.Section, querySection, StringComparison.OrdinalIgnoreCase));

                        return ApiResponse.Json(list.ToList());
                    }

                    if (method == "POST")
                    {
                        if (session == null || (session.Role != "admin" && session.Role != "coordinador"))
                            return ApiResponse.Error("Acceso no autorizado para crear horarios", 403);

                        var schedule = _serializer.Deserialize<Schedule>(bodyStr);
                        if (schedule == null || string.IsNullOrEmpty(schedule.Grade))
                            return ApiResponse.Error("El grado o año es obligatorio");

                        schedule.Id = "sch-" + Guid.NewGuid().ToString("N").Substring(0, 8);
                        schedule.UpdatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                        var db = _dbService.Get();
                        db.Schedules.Add(schedule);
                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Horario Creado", string.Format("{0} - Sección {1}", schedule.Grade, schedule.Section));
                        return ApiResponse.Success("Horario académico registrado con éxito", schedule);
                    }
                }

                if (path.StartsWith("/api/schedules/"))
                {
                    string id = path.Substring("/api/schedules/".Length).Trim();
                    var db = _dbService.Get();
                    var existing = db.Schedules.FirstOrDefault(s => s.Id == id);
                    if (existing == null) return ApiResponse.Error("Horario no encontrado", 404);

                    if (method == "GET")
                    {
                        return ApiResponse.Json(existing);
                    }

                    if (method == "PUT")
                    {
                        if (session == null || (session.Role != "admin" && session.Role != "coordinador"))
                            return ApiResponse.Error("Acceso no autorizado para modificar horarios", 403);

                        var updated = _serializer.Deserialize<Schedule>(bodyStr);
                        if (updated == null) return ApiResponse.Error("Datos inválidos");

                        existing.Level = updated.Level;
                        existing.Grade = updated.Grade;
                        existing.Section = updated.Section;
                        existing.Shift = updated.Shift;
                        existing.SchoolYear = updated.SchoolYear;
                        existing.Classroom = updated.Classroom;
                        existing.Coordinator = updated.Coordinator;
                        existing.Days = updated.Days ?? new List<DaySchedule>();
                        existing.UpdatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Horario Actualizado", string.Format("{0} - Sección {1}", existing.Grade, existing.Section));
                        return ApiResponse.Success("Horario académico actualizado satisfactoriamente", existing);
                    }

                    if (method == "DELETE")
                    {
                        if (session == null || (session.Role != "admin" && session.Role != "coordinador"))
                            return ApiResponse.Error("Acceso no autorizado", 403);

                        db.Schedules.Remove(existing);
                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Horario Eliminado", string.Format("{0} - Sección {1}", existing.Grade, existing.Section));
                        return ApiResponse.Success("Horario eliminado satisfactoriamente");
                    }
                }

                // ================= ENROLLMENTS =================
                if (path == "/api/enrollments")
                {
                    if (method == "GET")
                    {
                        if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                        var db = _dbService.Get();
                        return ApiResponse.Json(db.Enrollments.OrderByDescending(e => e.SubmittedAt).ToList());
                    }

                    // PUBLIC PRE-REGISTRATION SUBMISSION
                    if (method == "POST")
                    {
                        var enr = _serializer.Deserialize<Enrollment>(bodyStr);
                        if (enr == null || string.IsNullOrEmpty(enr.StudentFirstName) || string.IsNullOrEmpty(enr.ParentPhone))
                        {
                            return ApiResponse.Error("Por favor completa los datos obligatorios del alumno y representante");
                        }

                        var db = _dbService.Get();
                        enr.Id = Guid.NewGuid().ToString("N");
                        int count = db.Enrollments.Count + 1;
                        enr.Code = string.Format("INS-{0:yyyy}-{1:D4}", DateTime.Now, count);
                        enr.Status = "Pendiente";
                        enr.SubmittedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                        enr.UpdatedAt = enr.SubmittedAt;

                        db.Enrollments.Insert(0, enr);
                        _dbService.Save();
                        _dbService.LogAudit("PÚBLICO", "Pre-inscripción Recibida", string.Format("Código {0} - Alumno: {1} {2}", enr.Code, enr.StudentFirstName, enr.StudentLastName));

                        return ApiResponse.Success("Pre-inscripción enviada con éxito.", new { code = enr.Code, status = enr.Status });
                    }
                }

                if (path.StartsWith("/api/enrollments/"))
                {
                    string id = path.Substring("/api/enrollments/".Length).Trim();
                    var db = _dbService.Get();
                    var existing = db.Enrollments.FirstOrDefault(e => e.Id == id || e.Code == id);
                    if (existing == null) return ApiResponse.Error("Registro de inscripción no encontrado", 404);

                    if (method == "GET")
                    {
                        // Anyone with code can consult their status, or logged in admin
                        return ApiResponse.Json(existing);
                    }

                    if (method == "PUT")
                    {
                        if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                        var updated = _serializer.Deserialize<Enrollment>(bodyStr);
                        if (updated != null)
                        {
                            if (!string.IsNullOrEmpty(updated.Status)) existing.Status = updated.Status;
                            if (updated.AdminNotes != null) existing.AdminNotes = updated.AdminNotes;
                            existing.UpdatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                            _dbService.Save();
                            _dbService.LogAudit(session.Username, "Estado de Pre-inscripción Actualizado", string.Format("Código {0} -> {1}", existing.Code, existing.Status));
                            return ApiResponse.Success("Estado de pre-inscripción actualizado", existing);
                        }
                    }

                    if (method == "DELETE")
                    {
                        if (session == null || session.Role != "admin") return ApiResponse.Error("Acceso no autorizado", 403);
                        db.Enrollments.Remove(existing);
                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Pre-inscripción Eliminada", "Código: " + existing.Code);
                        return ApiResponse.Success("Registro eliminado");
                    }
                }

                // ================= USERS MANAGEMENT =================
                if (path == "/api/users")
                {
                    if (session == null || session.Role != "admin") return ApiResponse.Error("Acceso exclusivo para Administrador", 403);
                    var db = _dbService.Get();

                    if (method == "GET")
                    {
                        var safeUsers = db.Users.Select(u => new
                        {
                            id = u.Id,
                            username = u.Username,
                            fullName = u.FullName,
                            role = u.Role,
                            createdAt = u.CreatedAt
                        }).ToList();
                        return ApiResponse.Json(safeUsers);
                    }

                    if (method == "POST")
                    {
                        var data = _serializer.Deserialize<Dictionary<string, string>>(bodyStr);
                        if (data == null || !data.ContainsKey("username") || !data.ContainsKey("password"))
                            return ApiResponse.Error("Usuario y contraseña requeridos");

                        string uname = data["username"].Trim().ToLowerInvariant();
                        if (db.Users.Any(u => u.Username.Equals(uname, StringComparison.OrdinalIgnoreCase)))
                            return ApiResponse.Error("El nombre de usuario ya existe");

                        string salt = AuthManager.GenerateSalt();
                        string hash = AuthManager.HashPassword(data["password"], salt);

                        var newUser = new User
                        {
                            Id = Guid.NewGuid().ToString("N"),
                            Username = uname,
                            FullName = data.ContainsKey("fullName") ? data["fullName"] : uname,
                            Role = data.ContainsKey("role") ? data["role"] : "secretaria",
                            Salt = salt,
                            PasswordHash = hash,
                            CreatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                        };

                        db.Users.Add(newUser);
                        _dbService.Save();
                        _dbService.LogAudit(session.Username, "Usuario Creado", "Usuario: " + uname + " (Rol: " + newUser.Role + ")");
                        return ApiResponse.Success("Usuario registrado exitosamente");
                    }
                }

                // ================= MAINTENANCE & STATS =================
                if (path == "/api/maintenance/stats" && method == "GET")
                {
                    if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                    var db = _dbService.Get();
                    string dbFile = Path.Combine(_baseDir, "data", "database.json");
                    long dbBytes = File.Exists(dbFile) ? new FileInfo(dbFile).Length : 0;

                    string uploadsDir = Path.Combine(_baseDir, "data", "uploads");
                    int uploadFiles = Directory.Exists(uploadsDir) ? Directory.GetFiles(uploadsDir).Length : 0;

                    string backupsDir = Path.Combine(_baseDir, "data", "backups");
                    int backupFiles = Directory.Exists(backupsDir) ? Directory.GetFiles(backupsDir).Length : 0;

                    return ApiResponse.Json(new
                    {
                        databaseSizeBytes = dbBytes,
                        databaseSizeFormatted = string.Format("{0:0.##} KB", dbBytes / 1024.0),
                        totalUsers = db.Users.Count,
                        totalArticles = db.Articles.Count,
                        totalSchedules = db.Schedules.Count,
                        totalEnrollments = db.Enrollments.Count,
                        pendingEnrollments = db.Enrollments.Count(e => e.Status == "Pendiente"),
                        totalUploads = uploadFiles,
                        totalBackups = backupFiles,
                        serverTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                        schoolName = db.Settings.SchoolName
                    });
                }

                if (path == "/api/maintenance/backup")
                {
                    if (session == null) return ApiResponse.Error("Acceso no autorizado", 401);
                    if (method == "POST")
                    {
                        string file = _dbService.CreateBackup();
                        return ApiResponse.Success("Copia de seguridad guardada exitosamente en el servidor", new { file = Path.GetFileName(file) });
                    }
                    if (method == "GET")
                    {
                        var db = _dbService.Get();
                        string json = _serializer.Serialize(db);
                        var resp = new ApiResponse
                        {
                            StatusCode = 200,
                            ContentType = "application/json",
                            Body = Encoding.UTF8.GetBytes(json)
                        };
                        string filename = "respaldo_colegio_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".json";
                        resp.Headers["Content-Disposition"] = "attachment; filename=\"" + filename + "\"";
                        return resp;
                    }
                }

                if (path == "/api/maintenance/restore" && method == "POST")
                {
                    if (session == null || session.Role != "admin") return ApiResponse.Error("Solo el Administrador General puede restaurar la base de datos", 403);
                    var data = _serializer.Deserialize<Dictionary<string, string>>(bodyStr);
                    if (data == null || !data.ContainsKey("jsonContent")) return ApiResponse.Error("Contenido de copia de seguridad no proporcionado");

                    bool ok = _dbService.RestoreBackup(data["jsonContent"]);
                    if (ok)
                    {
                        return ApiResponse.Success("Base de datos restaurada correctamente.");
                    }
                    return ApiResponse.Error("El archivo de copia de seguridad no tiene un formato válido");
                }

                if (path == "/api/maintenance/audit" && method == "GET")
                {
                    if (session == null || session.Role != "admin") return ApiResponse.Error("Acceso no autorizado", 403);
                    var db = _dbService.Get();
                    return ApiResponse.Json(db.AuditLogs ?? new List<AuditLog>());
                }

                return ApiResponse.Error("Ruta de API no encontrada: " + path, 404);
            }
            catch (Exception ex)
            {
                return ApiResponse.Error("Error interno en el servidor: " + ex.Message, 500);
            }
        }

        private ApiResponse Login(string bodyStr)
        {
            var creds = _serializer.Deserialize<Dictionary<string, string>>(bodyStr);
            if (creds == null || !creds.ContainsKey("username") || !creds.ContainsKey("password"))
            {
                return ApiResponse.Error("Credenciales incompletas", 400);
            }

            string uname = creds["username"].Trim();
            string pass = creds["password"];

            var db = _dbService.Get();
            var user = db.Users.FirstOrDefault(u => u.Username.Equals(uname, StringComparison.OrdinalIgnoreCase));
            if (user == null || !AuthManager.VerifyPassword(pass, user.Salt, user.PasswordHash))
            {
                return ApiResponse.Error("Usuario o contraseña incorrectos", 401);
            }

            var session = AuthManager.CreateSession(user);
            _dbService.LogAudit(user.Username, "Inicio de Sesión", "Ingreso exitoso al panel de administración.");

            var resp = ApiResponse.Success("Autenticación exitosa", new
            {
                token = session.Token,
                username = user.Username,
                fullName = user.FullName,
                role = user.Role
            });

            resp.Headers["Set-Cookie"] = string.Format("session_token={0}; Path=/; HttpOnly; SameSite=Lax", session.Token);
            return resp;
        }

        private ApiResponse UploadImage(string bodyStr)
        {
            var data = _serializer.Deserialize<Dictionary<string, string>>(bodyStr);
            if (data == null || !data.ContainsKey("data"))
            {
                return ApiResponse.Error("No se proporcionó imagen", 400);
            }

            string raw = data["data"];
            string ext = ".jpg";
            int commaIdx = raw.IndexOf(',');
            if (commaIdx >= 0)
            {
                string header = raw.Substring(0, commaIdx);
                if (header.Contains("png")) ext = ".png";
                else if (header.Contains("webp")) ext = ".webp";
                else if (header.Contains("gif")) ext = ".gif";
                else if (header.Contains("svg")) ext = ".svg";
                raw = raw.Substring(commaIdx + 1);
            }

            byte[] imageBytes = Convert.FromBase64String(raw);
            if (imageBytes.Length > 10 * 1024 * 1024)
            {
                return ApiResponse.Error("La imagen no debe superar los 10 MB", 400);
            }

            string filename = "img_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 6) + ext;
            string uploadsDir = Path.Combine(_baseDir, "data", "uploads");
            string fullPath = Path.Combine(uploadsDir, filename);

            File.WriteAllBytes(fullPath, imageBytes);
            string url = "/uploads/" + filename;

            return ApiResponse.Success("Imagen subida con éxito", new { url = url, filename = filename });
        }
    }
}
