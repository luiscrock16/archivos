using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace DivinaProvidencia
{
    public class DatabaseService
    {
        private static readonly object _syncLock = new object();
        private readonly string _dbPath;
        private readonly string _backupsDir;
        private readonly JavaScriptSerializer _serializer;
        private DatabaseRoot _db;

        public DatabaseService(string baseDir)
        {
            string dataDir = Path.Combine(baseDir, "data");
            if (!Directory.Exists(dataDir)) Directory.CreateDirectory(dataDir);

            _backupsDir = Path.Combine(dataDir, "backups");
            if (!Directory.Exists(_backupsDir)) Directory.CreateDirectory(_backupsDir);

            string uploadsDir = Path.Combine(dataDir, "uploads");
            if (!Directory.Exists(uploadsDir)) Directory.CreateDirectory(uploadsDir);

            _dbPath = Path.Combine(dataDir, "database.json");
            _serializer = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };

            LoadOrCreate();
        }

        public DatabaseRoot Get()
        {
            lock (_syncLock)
            {
                return _db;
            }
        }

        public void Save()
        {
            lock (_syncLock)
            {
                string json = _serializer.Serialize(_db);
                string tempPath = _dbPath + ".tmp";
                File.WriteAllText(tempPath, json, Encoding.UTF8);
                if (File.Exists(_dbPath))
                {
                    File.Delete(_dbPath);
                }
                File.Move(tempPath, _dbPath);
            }
        }

        public string CreateBackup()
        {
            lock (_syncLock)
            {
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string backupFile = Path.Combine(_backupsDir, "respaldo_" + timestamp + ".json");
                string json = _serializer.Serialize(_db);
                File.WriteAllText(backupFile, json, Encoding.UTF8);
                LogAudit("SISTEMA", "Copia de Seguridad Creada", "Archivo: " + Path.GetFileName(backupFile));
                return backupFile;
            }
        }

        public bool RestoreBackup(string jsonContent)
        {
            lock (_syncLock)
            {
                try
                {
                    var restored = _serializer.Deserialize<DatabaseRoot>(jsonContent);
                    if (restored != null && restored.Settings != null && restored.Users != null)
                    {
                        // Backup current state first
                        CreateBackup();
                        _db = restored;
                        Save();
                        LogAudit("ADMIN", "Restauración de Base de Datos", "Base de datos restaurada satisfactoriamente.");
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error restaurando copia de seguridad: " + ex.Message);
                }
                return false;
            }
        }

        public void LogAudit(string user, string action, string details)
        {
            lock (_syncLock)
            {
                if (_db.AuditLogs == null) _db.AuditLogs = new List<AuditLog>();
                _db.AuditLogs.Insert(0, new AuditLog
                {
                    Id = Guid.NewGuid().ToString("N"),
                    Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    User = user ?? "Anónimo",
                    Action = action,
                    Details = details
                });

                // Keep last 500 audit logs
                if (_db.AuditLogs.Count > 500)
                {
                    _db.AuditLogs.RemoveRange(500, _db.AuditLogs.Count - 500);
                }
            }
        }

        private void LoadOrCreate()
        {
            lock (_syncLock)
            {
                if (File.Exists(_dbPath))
                {
                    try
                    {
                        string json = File.ReadAllText(_dbPath, Encoding.UTF8);
                        _db = _serializer.Deserialize<DatabaseRoot>(json);
                        if (_db != null && _db.Settings != null)
                        {
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Advertencia: No se pudo leer base de datos existente (" + ex.Message + "). Se recreará con datos base.");
                    }
                }

                _db = CreateSeedData();
                Save();
                CreateBackup();
            }
        }

        private DatabaseRoot CreateSeedData()
        {
            var db = new DatabaseRoot();

            // Institutional Settings
            db.Settings = new InstitutionSettings
            {
                SchoolName = "Colegio Divina Providencia",
                Slogan = "Educando con amor, fe y excelencia hacia el futuro",
                WelcomeTitle = "Bienvenidos a nuestra comunidad educativa",
                WelcomeText = "Formamos líderes con valores humanos y cristianos, excelencia académica, innovación tecnológica y compromiso social.",
                Mission = "Brindar una educación integral de alta calidad, orientada en sólidos principios morales y cristianos, desarrollando en cada estudiante sus potencialidades intelectuales, creativas, socio-emocionales y espirituales.",
                Vision = "Ser una institución educativa líder en la formación académica y valórica, reconocida por su excelencia pedagógica, espíritu de servicio y adaptación a los retos del mundo moderno.",
                Values = "Fe y Esperanza, Excelencia Académica, Respeto y Fraternidad, Responsabilidad y Disciplina, Solidaridad y Honestidad.",
                History = "Fundado con el propósito de formar integralmente a niños y jóvenes bajo la guía de la Divina Providencia, el colegio ha crecido como un faro de conocimiento y valores. A lo largo de las décadas hemos acompañado a numerosas promociones de graduados que hoy sirven con honor y vocación a la sociedad.",
                Address = "Av. Principal Divina Providencia, Sector Central, Edificio Institucional",
                Phone = "+58 (0212) 555-0199 / 555-0198",
                Email = "contacto@colegiodivinaprovidencia.edu",
                OfficeHours = "Lunes a Viernes de 7:30 a.m. a 3:30 p.m.",
                PrincipalName = "Prof. Hermana María Teresa González",
                EnrollmentOpen = true,
                EnrollmentNotice = "Proceso de Inscripciones Abierto para el Año Escolar 2026-2027. Cupos disponibles para Educación Primaria y Bachillerato.",
                PrimaryColor = "#1E3A8A",
                SecondaryColor = "#2563EB"
            };

            // Users
            string saltAdmin = AuthManager.GenerateSalt();
            string saltCoord = AuthManager.GenerateSalt();
            string saltSecre = AuthManager.GenerateSalt();

            db.Users.Add(new User
            {
                Id = Guid.NewGuid().ToString("N"),
                Username = "admin",
                Salt = saltAdmin,
                PasswordHash = AuthManager.HashPassword("admin123", saltAdmin),
                FullName = "Administrador General",
                Role = "admin",
                CreatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            });

            db.Users.Add(new User
            {
                Id = Guid.NewGuid().ToString("N"),
                Username = "coordinador",
                Salt = saltCoord,
                PasswordHash = AuthManager.HashPassword("coord123", saltCoord),
                FullName = "Prof. Roberto Mendoza (Coordinador)",
                Role = "coordinador",
                CreatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            });

            db.Users.Add(new User
            {
                Id = Guid.NewGuid().ToString("N"),
                Username = "secretaria",
                Salt = saltSecre,
                PasswordHash = AuthManager.HashPassword("secre123", saltSecre),
                FullName = "Lic. Andrea Morales (Secretaría)",
                Role = "secretaria",
                CreatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            });

            // Articles / News
            db.Articles.Add(new Article
            {
                Id = Guid.NewGuid().ToString("N"),
                Title = "Apertura Oficial del Año Escolar 2026-2027",
                Slug = "apertura-escolar-2026-2027",
                Category = "academico",
                Summary = "Damos la bienvenida a toda nuestra comunidad educativa al nuevo ciclo escolar cargado de proyectos formativos.",
                Content = "Con gran alegría y devoción, el Colegio Divina Providencia dio inicio formal al ciclo escolar 2026-2027. Durante el acto cívico inaugural, el equipo directivo y docente presentó el plan de innovación pedagógica que incluye nuevas herramientas tecnológicas, talleres de robótica y el fortalecimiento de nuestro programa de valores cristianos.",
                ImageUrl = "/images/noticia1.svg",
                Author = "Dirección Académica",
                PublishedAt = "2026-10-15",
                IsFeatured = true,
                IsPublished = true
            });

            db.Articles.Add(new Article
            {
                Id = Guid.NewGuid().ToString("N"),
                Title = "Jornada Intercolegial de Ciencias y Tecnología",
                Slug = "jornada-ciencias-tecnologia",
                Category = "evento",
                Summary = "Nuestros estudiantes de bachillerato expusieron proyectos de robótica, energías limpias y programación.",
                Content = "La feria anual de ciencias reunió a más de 40 proyectos estudiantiles destacados. Los alumnos demostraron habilidades extraordinarias en prototipos de automatización, maquetas ecológicas y experimentos de química y física aplicada, reafirmando el compromiso de nuestra institución con la vanguardia científica.",
                ImageUrl = "/images/noticia2.svg",
                Author = "Coordinación de Ciencias",
                PublishedAt = "2026-10-22",
                IsFeatured = true,
                IsPublished = true
            });

            db.Articles.Add(new Article
            {
                Id = Guid.NewGuid().ToString("N"),
                Title = "Torneo Deportivo Intercursos 'Copa Divina Providencia'",
                Slug = "torneo-deportivo-intercursos",
                Category = "evento",
                Summary = "Este próximo viernes inician los encuentros de fútbol sala, voleibol y básquetbol en nuestras canchas.",
                Content = "Invitamos a toda la comunidad estudiantil y a los padres de familia a apoyar a sus equipos en el torneo deportivo. Promover el compañerismo, la disciplina, el trabajo en equipo y el bienestar físico es un pilar fundamental en nuestro proyecto educativo.",
                ImageUrl = "/images/noticia3.svg",
                Author = "Depto. Educación Física",
                PublishedAt = "2026-10-28",
                IsFeatured = false,
                IsPublished = true
            });

            db.Articles.Add(new Article
            {
                Id = Guid.NewGuid().ToString("N"),
                Title = "Convocatoria: Jornada de Atención y Entrega de Boletines",
                Slug = "entrega-de-boletines-primer-lapso",
                Category = "comunicado",
                Summary = "Fechas y horarios de atención individual con profesores guías para representantes de todos los niveles.",
                Content = "Se informa a los señores representantes que el proceso de entrega de evaluaciones y orientación pedagógica individual se llevará a cabo durante la primera semana del próximo mes. Rogamos puntualidad y asistencia con el documento de identidad.",
                ImageUrl = "/images/noticia4.svg",
                Author = "Secretaría Escolar",
                PublishedAt = "2026-10-29",
                IsFeatured = false,
                IsPublished = true
            });

            // Sample Schedules
            db.Schedules.Add(CreateSampleSchedule1roA());
            db.Schedules.Add(CreateSampleSchedule2doA());
            db.Schedules.Add(CreateSampleSchedule3roPrimaria());
            db.Schedules.Add(CreateSampleSchedule6toPrimaria());

            // Sample Enrollments
            db.Enrollments.Add(new Enrollment
            {
                Id = Guid.NewGuid().ToString("N"),
                Code = "INS-2026-001",
                StudentFirstName = "Mateo Alejandro",
                StudentLastName = "Rivas Castillo",
                StudentDocId = "V-34.891.220",
                BirthDate = "2013-05-14",
                Gender = "Masculino",
                GradeApplying = "1er Año Bachillerato",
                AcademicYear = "2026-2027",
                PreviousSchool = "U.E. San José",
                ParentFirstName = "Carlos",
                ParentLastName = "Rivas Peña",
                ParentDocId = "V-15.678.901",
                ParentPhone = "0414-3321455",
                ParentEmail = "carlos.rivas@gmail.com",
                ParentAddress = "Urb. Las Flores, Calle 4, Casa #12",
                Status = "Aprobado",
                AdminNotes = "Documentos completos consignados en secretaría.",
                SubmittedAt = "2026-10-18 10:15",
                UpdatedAt = "2026-10-20 14:00"
            });

            db.Enrollments.Add(new Enrollment
            {
                Id = Guid.NewGuid().ToString("N"),
                Code = "INS-2026-002",
                StudentFirstName = "Valeria Sofía",
                StudentLastName = "Navarro Duque",
                StudentDocId = "V-36.102.488",
                BirthDate = "2015-08-22",
                Gender = "Femenino",
                GradeApplying = "5to Grado Primaria",
                AcademicYear = "2026-2027",
                PreviousSchool = "Colegio Santa Ana",
                ParentFirstName = "Lucía",
                ParentLastName = "Duque de Navarro",
                ParentDocId = "V-17.204.899",
                ParentPhone = "0424-8891230",
                ParentEmail = "lucianavarro@outlook.com",
                ParentAddress = "Residencias El Parque, Apto 5-B",
                Status = "Pendiente",
                AdminNotes = "Pendiente por validar notas certificadas.",
                SubmittedAt = "2026-10-25 16:40",
                UpdatedAt = "2026-10-25 16:40"
            });

            // Initial Audit Log
            db.AuditLogs.Add(new AuditLog
            {
                Id = Guid.NewGuid().ToString("N"),
                Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                User = "SISTEMA",
                Action = "Inicialización del Sistema",
                Details = "Base de datos inicializada con configuración institucional del Colegio Divina Providencia."
            });

            return db;
        }

        private Schedule CreateSampleSchedule1roA()
        {
            var sch = new Schedule
            {
                Id = "sch-1ro-bach-a",
                Level = "Bachillerato",
                Grade = "1er Año",
                Section = "A",
                Shift = "Mañana",
                SchoolYear = "2026-2027",
                Classroom = "Aula 101 (Pabellón Norte)",
                Coordinator = "Prof. Roberto Mendoza",
                UpdatedAt = "2026-10-25"
            };

            // Lunes
            var lun = new DaySchedule { Day = "Lunes" };
            lun.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Acto Cívico / Valores Cristianos", Teacher = "Hna. María Teresa", Room = "Patio Central" });
            lun.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 101" });
            lun.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 101" });
            lun.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            lun.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Lengua y Literatura", Teacher = "Prof. Patricia Silva", Room = "Aula 101" });
            lun.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Lengua y Literatura", Teacher = "Prof. Patricia Silva", Room = "Aula 101" });
            lun.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Geografía e Historia", Teacher = "Prof. Marcos Díaz", Room = "Aula 101" });
            sch.Days.Add(lun);

            // Martes
            var mar = new DaySchedule { Day = "Martes" };
            mar.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Ciencias Naturales", Teacher = "Prof. Laura Benítez", Room = "Laboratorio 1" });
            mar.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Ciencias Naturales", Teacher = "Prof. Laura Benítez", Room = "Laboratorio 1" });
            mar.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Inglés", Teacher = "Prof. David Clark", Room = "Aula 101" });
            mar.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            mar.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Inglés", Teacher = "Prof. David Clark", Room = "Aula 101" });
            mar.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Educación Física y Deportes", Teacher = "Prof. Manuel Peña", Room = "Cancha Polideportiva" });
            mar.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Educación Física y Deportes", Teacher = "Prof. Manuel Peña", Room = "Cancha Polideportiva" });
            sch.Days.Add(mar);

            // Miércoles
            var mie = new DaySchedule { Day = "Miércoles" };
            mie.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Computación e Informática", Teacher = "Ing. Gabriel Suárez", Room = "Laboratorio Informática" });
            mie.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Computación e Informática", Teacher = "Ing. Gabriel Suárez", Room = "Laboratorio Informática" });
            mie.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 101" });
            mie.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            mie.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Arte y Patrimonio", Teacher = "Lic. Sofía Rengel", Room = "Taller de Artes" });
            mie.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Arte y Patrimonio", Teacher = "Lic. Sofía Rengel", Room = "Taller de Artes" });
            mie.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Orientación y Convivencia", Teacher = "Prof. Roberto Mendoza", Room = "Aula 101" });
            sch.Days.Add(mie);

            // Jueves
            var jue = new DaySchedule { Day = "Jueves" };
            jue.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Lengua y Literatura", Teacher = "Prof. Patricia Silva", Room = "Aula 101" });
            jue.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Geografía e Historia", Teacher = "Prof. Marcos Díaz", Room = "Aula 101" });
            jue.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Geografía e Historia", Teacher = "Prof. Marcos Díaz", Room = "Aula 101" });
            jue.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            jue.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Ciencias Naturales", Teacher = "Prof. Laura Benítez", Room = "Laboratorio 1" });
            jue.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Ciencias Naturales", Teacher = "Prof. Laura Benítez", Room = "Laboratorio 1" });
            jue.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "G.H.C. Prácticas", Teacher = "Prof. Marcos Díaz", Room = "Aula 101" });
            sch.Days.Add(jue);

            // Viernes
            var vie = new DaySchedule { Day = "Viernes" };
            vie.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 101" });
            vie.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Inglés", Teacher = "Prof. David Clark", Room = "Aula 101" });
            vie.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Inglés", Teacher = "Prof. David Clark", Room = "Aula 101" });
            vie.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            vie.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Grupo de Creación y Producción (Teatro/Música)", Teacher = "Prof. Elena Méndez", Room = "Auditorio" });
            vie.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Grupo de Creación y Producción (Robótica)", Teacher = "Ing. Gabriel Suárez", Room = "Lab. Robótica" });
            vie.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Formación Humana y Espiritual", Teacher = "Hna. María Teresa", Room = "Capilla / Aula 101" });
            sch.Days.Add(vie);

            return sch;
        }

        private Schedule CreateSampleSchedule2doA()
        {
            var sch = new Schedule
            {
                Id = "sch-2do-bach-a",
                Level = "Bachillerato",
                Grade = "2do Año",
                Section = "A",
                Shift = "Mañana",
                SchoolYear = "2026-2027",
                Classroom = "Aula 102",
                Coordinator = "Prof. Roberto Mendoza",
                UpdatedAt = "2026-10-25"
            };

            var lun = new DaySchedule { Day = "Lunes" };
            lun.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Acto Cívico", Teacher = "Dirección", Room = "Patio Central" });
            lun.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Física Fundamental", Teacher = "Prof. Hernán Acosta", Room = "Aula 102" });
            lun.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Física Fundamental", Teacher = "Prof. Hernán Acosta", Room = "Aula 102" });
            lun.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            lun.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 102" });
            lun.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 102" });
            lun.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Inglés", Teacher = "Prof. David Clark", Room = "Aula 102" });
            sch.Days.Add(lun);

            var mar = new DaySchedule { Day = "Martes" };
            mar.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Biología", Teacher = "Prof. Laura Benítez", Room = "Laboratorio 2" });
            mar.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Biología", Teacher = "Prof. Laura Benítez", Room = "Laboratorio 2" });
            mar.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Castellano", Teacher = "Prof. Patricia Silva", Room = "Aula 102" });
            mar.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            mar.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Castellano", Teacher = "Prof. Patricia Silva", Room = "Aula 102" });
            mar.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Historia Universal", Teacher = "Prof. Marcos Díaz", Room = "Aula 102" });
            mar.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Historia Universal", Teacher = "Prof. Marcos Díaz", Room = "Aula 102" });
            sch.Days.Add(mar);

            var mie = new DaySchedule { Day = "Miércoles" };
            mie.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Educación Física", Teacher = "Prof. Manuel Peña", Room = "Cancha" });
            mie.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Educación Física", Teacher = "Prof. Manuel Peña", Room = "Cancha" });
            mie.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 102" });
            mie.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            mie.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Informática", Teacher = "Ing. Gabriel Suárez", Room = "Laboratorio" });
            mie.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Informática", Teacher = "Ing. Gabriel Suárez", Room = "Laboratorio" });
            mie.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Valores Cristianos", Teacher = "Hna. María Teresa", Room = "Aula 102" });
            sch.Days.Add(mie);

            var jue = new DaySchedule { Day = "Jueves" };
            jue.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Inglés", Teacher = "Prof. David Clark", Room = "Aula 102" });
            jue.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Inglés", Teacher = "Prof. David Clark", Room = "Aula 102" });
            jue.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Física Fundamental", Teacher = "Prof. Hernán Acosta", Room = "Aula 102" });
            jue.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            jue.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Castellano", Teacher = "Prof. Patricia Silva", Room = "Aula 102" });
            jue.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Arte y Tradición", Teacher = "Lic. Sofía Rengel", Room = "Taller" });
            jue.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Arte y Tradición", Teacher = "Lic. Sofía Rengel", Room = "Taller" });
            sch.Days.Add(jue);

            var vie = new DaySchedule { Day = "Viernes" };
            vie.Periods.Add(new Period { Time = "07:00 - 07:45", Subject = "Biología", Teacher = "Prof. Laura Benítez", Room = "Laboratorio" });
            vie.Periods.Add(new Period { Time = "07:45 - 08:30", Subject = "Matemáticas", Teacher = "Prof. Carlos Ramos", Room = "Aula 102" });
            vie.Periods.Add(new Period { Time = "08:30 - 09:15", Subject = "Historia", Teacher = "Prof. Marcos Díaz", Room = "Aula 102" });
            vie.Periods.Add(new Period { Time = "09:15 - 09:45", Subject = "RECESO", Teacher = "-", Room = "Área Social" });
            vie.Periods.Add(new Period { Time = "09:45 - 10:30", Subject = "Proyecto de Innovación", Teacher = "Ing. Gabriel Suárez", Room = "Taller" });
            vie.Periods.Add(new Period { Time = "10:30 - 11:15", Subject = "Proyecto de Innovación", Teacher = "Ing. Gabriel Suárez", Room = "Taller" });
            vie.Periods.Add(new Period { Time = "11:15 - 12:00", Subject = "Orientación Vocacional", Teacher = "Prof. Roberto Mendoza", Room = "Aula 102" });
            sch.Days.Add(vie);

            return sch;
        }

        private Schedule CreateSampleSchedule3roPrimaria()
        {
            var sch = new Schedule
            {
                Id = "sch-3ro-prim-a",
                Level = "Primaria",
                Grade = "3er Grado",
                Section = "A",
                Shift = "Mañana",
                SchoolYear = "2026-2027",
                Classroom = "Aula 301 (Piso 1)",
                Coordinator = "Lic. Andrea Morales",
                UpdatedAt = "2026-10-24"
            };

            string[] dias = { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes" };
            foreach (var d in dias)
            {
                var ds = new DaySchedule { Day = d };
                ds.Periods.Add(new Period { Time = "07:15 - 08:00", Subject = (d == "Lunes") ? "Acto Cívico y Oración" : "Lenguaje y Comprensión", Teacher = "Docente Guía: Profa. Carmen Linares", Room = "Aula 301" });
                ds.Periods.Add(new Period { Time = "08:00 - 08:45", Subject = "Matemática Divertida", Teacher = "Profa. Carmen Linares", Room = "Aula 301" });
                ds.Periods.Add(new Period { Time = "08:45 - 09:30", Subject = (d == "Martes" || d == "Jueves") ? "Inglés Primaria" : "Ciencias y Naturaleza", Teacher = "Profa. Carmen Linares", Room = "Aula 301" });
                ds.Periods.Add(new Period { Time = "09:30 - 10:00", Subject = "RECESO Y MERIENDA", Teacher = "-", Room = "Patio Infantil" });
                ds.Periods.Add(new Period { Time = "10:00 - 10:45", Subject = (d == "Miércoles") ? "Educación Física" : "Sociales y Ciudadanía", Teacher = "Prof. Manuel Peña / Profa. Carmen", Room = "Cancha / Aula 301" });
                ds.Periods.Add(new Period { Time = "10:45 - 11:30", Subject = (d == "Viernes") ? "Taller de Artes Plásticas" : "Lectura y Caligrafía", Teacher = "Profa. Carmen Linares", Room = "Aula 301" });
                ds.Periods.Add(new Period { Time = "11:30 - 12:00", Subject = "Valores y Espiritualidad", Teacher = "Hna. María Teresa", Room = "Aula 301" });
                sch.Days.Add(ds);
            }

            return sch;
        }

        private Schedule CreateSampleSchedule6toPrimaria()
        {
            var sch = new Schedule
            {
                Id = "sch-6to-prim-b",
                Level = "Primaria",
                Grade = "6to Grado",
                Section = "B",
                Shift = "Mañana",
                SchoolYear = "2026-2027",
                Classroom = "Aula 304",
                Coordinator = "Lic. Andrea Morales",
                UpdatedAt = "2026-10-24"
            };

            string[] dias = { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes" };
            foreach (var d in dias)
            {
                var ds = new DaySchedule { Day = d };
                ds.Periods.Add(new Period { Time = "07:15 - 08:00", Subject = "Aritmética y Geometría", Teacher = "Prof. Javier Castillo", Room = "Aula 304" });
                ds.Periods.Add(new Period { Time = "08:00 - 08:45", Subject = "Aritmética y Geometría", Teacher = "Prof. Javier Castillo", Room = "Aula 304" });
                ds.Periods.Add(new Period { Time = "08:45 - 09:30", Subject = "Lengua y Ortografía", Teacher = "Profa. Clara Beltrán", Room = "Aula 304" });
                ds.Periods.Add(new Period { Time = "09:30 - 10:00", Subject = "RECESO", Teacher = "-", Room = "Patio Central" });
                ds.Periods.Add(new Period { Time = "10:00 - 10:45", Subject = (d == "Lunes" || d == "Jueves") ? "Ciencias Naturales" : "Inglés Básico", Teacher = "Prof. Javier Castillo", Room = "Aula 304" });
                ds.Periods.Add(new Period { Time = "10:45 - 11:30", Subject = (d == "Miércoles") ? "Educación Física" : "Historia y Geografía", Teacher = "Prof. Manuel Peña", Room = "Cancha" });
                ds.Periods.Add(new Period { Time = "11:30 - 12:00", Subject = "Tecnología e Informática", Teacher = "Ing. Gabriel Suárez", Room = "Laboratorio" });
                sch.Days.Add(ds);
            }

            return sch;
        }
    }
}
