using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace DivinaProvidencia
{
    public class HttpServer
    {
        private readonly int _port;
        private readonly string _wwwroot;
        private readonly string _uploadsDir;
        private readonly ApiHandler _apiHandler;
        private TcpListener _listener;
        private bool _isRunning;

        private static readonly Dictionary<string, string> _mimeTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { ".html", "text/html; charset=utf-8" },
            { ".htm", "text/html; charset=utf-8" },
            { ".css", "text/css; charset=utf-8" },
            { ".js", "application/javascript; charset=utf-8" },
            { ".json", "application/json; charset=utf-8" },
            { ".svg", "image/svg+xml" },
            { ".png", "image/png" },
            { ".jpg", "image/jpeg" },
            { ".jpeg", "image/jpeg" },
            { ".gif", "image/gif" },
            { ".webp", "image/webp" },
            { ".ico", "image/x-icon" },
            { ".pdf", "application/pdf" },
            { ".woff", "font/woff" },
            { ".woff2", "font/woff2" },
            { ".ttf", "font/ttf" },
            { ".txt", "text/plain; charset=utf-8" }
        };

        public HttpServer(int port, string baseDir, ApiHandler apiHandler)
        {
            _port = port;
            _wwwroot = Path.Combine(baseDir, "wwwroot");
            _uploadsDir = Path.Combine(baseDir, "data", "uploads");
            _apiHandler = apiHandler;
        }

        public void Start()
        {
            _listener = new TcpListener(IPAddress.Any, _port);
            _listener.Start();
            _isRunning = true;

            ThreadPool.QueueUserWorkItem(ListenLoop);
        }

        public void Stop()
        {
            _isRunning = false;
            try
            {
                _listener.Stop();
            }
            catch { }
        }

        private void ListenLoop(object state)
        {
            while (_isRunning)
            {
                try
                {
                    TcpClient client = _listener.AcceptTcpClient();
                    ThreadPool.QueueUserWorkItem(HandleClient, client);
                }
                catch (SocketException)
                {
                    if (!_isRunning) break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error en escucha: " + ex.Message);
                }
            }
        }

        private void HandleClient(object clientObj)
        {
            var client = (TcpClient)clientObj;
            try
            {
                client.ReceiveTimeout = 30000;
                client.SendTimeout = 30000;

                using (NetworkStream stream = client.GetStream())
                using (var reader = new BinaryReader(stream))
                {
                    // Read request header line by line
                    string requestLine = ReadLine(stream);
                    if (string.IsNullOrEmpty(requestLine))
                    {
                        client.Close();
                        return;
                    }

                    string[] lineParts = requestLine.Split(' ');
                    if (lineParts.Length < 2)
                    {
                        client.Close();
                        return;
                    }

                    string method = lineParts[0].ToUpperInvariant();
                    string rawUrl = lineParts[1];

                    // Headers
                    var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    string headerLine;
                    while (!string.IsNullOrEmpty(headerLine = ReadLine(stream)))
                    {
                        int colon = headerLine.IndexOf(':');
                        if (colon > 0)
                        {
                            string key = headerLine.Substring(0, colon).Trim();
                            string val = headerLine.Substring(colon + 1).Trim();
                            headers[key] = val;
                        }
                    }

                    // CORS preflight
                    if (method == "OPTIONS")
                    {
                        SendResponse(stream, 204, "No Content", new Dictionary<string, string>
                        {
                            { "Access-Control-Allow-Origin", "*" },
                            { "Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS" },
                            { "Access-Control-Allow-Headers", "Content-Type, Authorization, Cookie" },
                            { "Access-Control-Allow-Credentials", "true" }
                        }, new byte[0]);
                        return;
                    }

                    // Read Body if Content-Length specified
                    byte[] bodyBytes = new byte[0];
                    if (headers.ContainsKey("Content-Length"))
                    {
                        int contentLength;
                        if (int.TryParse(headers["Content-Length"], out contentLength) && contentLength > 0)
                        {
                            bodyBytes = new byte[contentLength];
                            int totalRead = 0;
                            while (totalRead < contentLength)
                            {
                                int read = stream.Read(bodyBytes, totalRead, contentLength - totalRead);
                                if (read <= 0) break;
                                totalRead += read;
                            }
                        }
                    }

                    // Parse path & query
                    string path = rawUrl;
                    var query = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    int qIdx = rawUrl.IndexOf('?');
                    if (qIdx >= 0)
                    {
                        path = rawUrl.Substring(0, qIdx);
                        string qStr = rawUrl.Substring(qIdx + 1);
                        string[] pairs = qStr.Split('&');
                        foreach (var pair in pairs)
                        {
                            int eq = pair.IndexOf('=');
                            if (eq > 0)
                            {
                                string k = Uri.UnescapeDataString(pair.Substring(0, eq));
                                string v = Uri.UnescapeDataString(pair.Substring(eq + 1));
                                query[k] = v;
                            }
                        }
                    }

                    // Resolve session
                    UserSession session = ResolveSession(headers);

                    // ================= API ROUTE =================
                    if (path.StartsWith("/api/"))
                    {
                        string bodyStr = Encoding.UTF8.GetString(bodyBytes);
                        var apiResp = _apiHandler.Handle(method, path, query, bodyStr, session);

                        var respHeaders = new Dictionary<string, string>
                        {
                            { "Content-Type", apiResp.ContentType },
                            { "Access-Control-Allow-Origin", "*" },
                            { "Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS" },
                            { "Access-Control-Allow-Headers", "Content-Type, Authorization, Cookie" }
                        };
                        foreach (var h in apiResp.Headers)
                        {
                            respHeaders[h.Key] = h.Value;
                        }

                        SendResponse(stream, apiResp.StatusCode, GetStatusText(apiResp.StatusCode), respHeaders, apiResp.Body);
                        return;
                    }

                    // ================= UPLOADS ROUTE =================
                    if (path.StartsWith("/uploads/"))
                    {
                        string filename = Path.GetFileName(path.Substring("/uploads/".Length));
                        string filePath = Path.Combine(_uploadsDir, filename);
                        ServeFile(stream, filePath);
                        return;
                    }

                    // ================= STATIC FILES ROUTE =================
                    ServeStatic(stream, path);
                }
            }
            catch
            {
                // Connection terminated or client disconnected
            }
            finally
            {
                try { client.Close(); } catch { }
            }
        }

        private UserSession ResolveSession(Dictionary<string, string> headers)
        {
            // 1. Authorization header: "Bearer <token>"
            if (headers.ContainsKey("Authorization"))
            {
                string auth = headers["Authorization"];
                if (auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                {
                    string token = auth.Substring("Bearer ".Length).Trim();
                    var sess = AuthManager.ValidateToken(token);
                    if (sess != null) return sess;
                }
            }

            // 2. Cookie header: "session_token=<token>"
            if (headers.ContainsKey("Cookie"))
            {
                string cookieHeader = headers["Cookie"];
                string[] cookies = cookieHeader.Split(';');
                foreach (var c in cookies)
                {
                    string[] kv = c.Trim().Split('=');
                    if (kv.Length == 2 && kv[0].Trim() == "session_token")
                    {
                        var sess = AuthManager.ValidateToken(kv[1].Trim());
                        if (sess != null) return sess;
                    }
                }
            }

            return null;
        }

        private void ServeStatic(NetworkStream stream, string urlPath)
        {
            if (urlPath == "/" || string.IsNullOrEmpty(urlPath))
            {
                urlPath = "/index.html";
            }

            // Sanitize urlPath to prevent directory traversal
            string relPath = urlPath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
            string fullPath = Path.GetFullPath(Path.Combine(_wwwroot, relPath));

            if (!fullPath.StartsWith(_wwwroot, StringComparison.OrdinalIgnoreCase))
            {
                Send404(stream);
                return;
            }

            if (File.Exists(fullPath))
            {
                ServeFile(stream, fullPath);
            }
            else
            {
                // Fallback for SPA routing to index.html if not an asset file
                string ext = Path.GetExtension(fullPath);
                if (string.IsNullOrEmpty(ext) || ext == ".html")
                {
                    string indexFile = Path.Combine(_wwwroot, "index.html");
                    if (File.Exists(indexFile))
                    {
                        ServeFile(stream, indexFile);
                        return;
                    }
                }
                Send404(stream);
            }
        }

        private void ServeFile(NetworkStream stream, string filePath)
        {
            if (!File.Exists(filePath))
            {
                Send404(stream);
                return;
            }

            string ext = Path.GetExtension(filePath);
            string mimeType = "application/octet-stream";
            if (_mimeTypes.ContainsKey(ext))
            {
                mimeType = _mimeTypes[ext];
            }

            byte[] fileBytes = File.ReadAllBytes(filePath);
            var headers = new Dictionary<string, string>
            {
                { "Content-Type", mimeType },
                { "Cache-Control", "no-cache" }
            };

            SendResponse(stream, 200, "OK", headers, fileBytes);
        }

        private void Send404(NetworkStream stream)
        {
            string html = "<!DOCTYPE html><html lang='es'><head><meta charset='utf-8'><title>404 - No Encontrado</title><style>body{font-family:sans-serif;text-align:center;padding:50px;background:#f8fafc;color:#1e3a8a;}</style></head><body><h1>404 - Página No Encontrada</h1><p>El recurso solicitado no existe en el servidor local del Colegio Divina Providencia.</p><p><a href='/'>Volver al Inicio</a></p></body></html>";
            byte[] bytes = Encoding.UTF8.GetBytes(html);
            SendResponse(stream, 404, "Not Found", new Dictionary<string, string>
            {
                { "Content-Type", "text/html; charset=utf-8" }
            }, bytes);
        }

        private void SendResponse(NetworkStream stream, int code, string statusText, Dictionary<string, string> headers, byte[] body)
        {
            var sb = new StringBuilder();
            sb.AppendFormat("HTTP/1.1 {0} {1}\r\n", code, statusText);
            sb.AppendFormat("Content-Length: {0}\r\n", body.Length);
            sb.Append("Connection: close\r\n");

            if (headers != null)
            {
                foreach (var h in headers)
                {
                    sb.AppendFormat("{0}: {1}\r\n", h.Key, h.Value);
                }
            }
            sb.Append("\r\n");

            byte[] headerBytes = Encoding.UTF8.GetBytes(sb.ToString());
            stream.Write(headerBytes, 0, headerBytes.Length);
            if (body.Length > 0)
            {
                stream.Write(body, 0, body.Length);
            }
            stream.Flush();
        }

        private string ReadLine(NetworkStream stream)
        {
            var bytes = new List<byte>();
            int prev = -1;
            while (true)
            {
                int b = stream.ReadByte();
                if (b == -1) break;
                if (prev == '\r' && b == '\n')
                {
                    bytes.RemoveAt(bytes.Count - 1); // remove \r
                    break;
                }
                bytes.Add((byte)b);
                prev = b;
            }

            if (bytes.Count == 0 && prev == -1) return null;
            return Encoding.UTF8.GetString(bytes.ToArray());
        }

        private string GetStatusText(int code)
        {
            switch (code)
            {
                case 200: return "OK";
                case 201: return "Created";
                case 204: return "No Content";
                case 301: return "Moved Permanently";
                case 302: return "Found";
                case 400: return "Bad Request";
                case 401: return "Unauthorized";
                case 403: return "Forbidden";
                case 404: return "Not Found";
                case 500: return "Internal Server Error";
                default: return "OK";
            }
        }
    }
}
