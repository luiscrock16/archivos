using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Threading;

namespace DivinaProvidencia
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Colegio Divina Providencia - Servidor Local";
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            int port = 5000;
            if (args.Length > 0 && int.TryParse(args[0], out int customPort))
            {
                port = customPort;
            }

            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            // If running inside bin/ folder or direct, find workspace root containing wwwroot
            if (!Directory.Exists(Path.Combine(baseDir, "wwwroot")) && Directory.Exists(Path.Combine(baseDir, "..", "wwwroot")))
            {
                baseDir = Path.GetFullPath(Path.Combine(baseDir, ".."));
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===============================================================================");
            Console.WriteLine("                    COLEGIO DIVINA PROVIDENCIA                                 ");
            Console.WriteLine("              SISTEMA INSTITUCIONAL DE GESTIÓN LOCAL                           ");
            Console.WriteLine("===============================================================================");
            Console.ResetColor();

            Console.WriteLine("Iniciando componentes del sistema...");
            var dbService = new DatabaseService(baseDir);
            var apiHandler = new ApiHandler(dbService, baseDir);
            var server = new HttpServer(port, baseDir, apiHandler);

            try
            {
                server.Start();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR CRÍTICO: No se pudo iniciar el servidor en el puerto " + port);
                Console.WriteLine("Detalle: " + ex.Message);
                Console.ResetColor();
                Console.WriteLine("\nPresiona cualquier tecla para salir...");
                Console.ReadKey();
                return;
            }

            var localIps = GetLocalIPv4Addresses();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n[✔] SERVIDOR LOCAL INICIADO Y EN LÍNEA CORRECTAMENTE");
            Console.ResetColor();

            Console.WriteLine("\n-------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" CÓMO ACCEDER AL SISTEMA:");
            Console.ResetColor();
            Console.WriteLine(" 1. En ESTA computadora principal (Servidor):");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("    -> http://localhost:" + port);
            Console.WriteLine("    -> http://127.0.0.1:" + port);
            Console.ResetColor();

            Console.WriteLine("\n 2. En COMPUTADORAS SECUNDARIAS (Coordinación, Secretaría, Docentes, Alumnos):");
            Console.WriteLine("    (Deben estar conectadas al mismo WiFi o cable de red del colegio)");
            if (localIps.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("    -> No se detectó interfaz de red activa. Conecta el cable o WiFi.");
                Console.ResetColor();
            }
            else
            {
                foreach (var ip in localIps)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("    -> http://" + ip + ":" + port);
                    Console.ResetColor();
                }
            }

            Console.WriteLine("-------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(" CUENTAS DE ACCESO ADMINISTRATIVO (Configurables en el Panel):");
            Console.ResetColor();
            Console.WriteLine(" • Administrador:  Usuario: admin       | Contraseña: admin123");
            Console.WriteLine(" • Coordinación:   Usuario: coordinador | Contraseña: coord123");
            Console.WriteLine(" • Secretaría:     Usuario: secretaria  | Contraseña: secre123");
            Console.WriteLine("-------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine(" NOTA: Si una computadora secundaria no puede entrar, verifica que el Firewall");
            Console.WriteLine(" de Windows permita conexiones entrantes al puerto " + port + ".");
            Console.WriteLine(" Presiona Ctrl + C en esta ventana para detener el servidor de forma segura.");
            Console.WriteLine("-------------------------------------------------------------------------------\n");

            // Keep main thread alive
            var waitHandle = new ManualResetEvent(false);
            Console.CancelKeyPress += (s, e) =>
            {
                e.Cancel = true;
                Console.WriteLine("\nDeteniendo servidor de forma segura...");
                server.Stop();
                dbService.Save();
                Console.WriteLine("Servidor detenido. ¡Hasta pronto!");
                waitHandle.Set();
            };

            waitHandle.WaitOne();
        }

        private static List<string> GetLocalIPv4Addresses()
        {
            var ips = new List<string>();
            try
            {
                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;

                    var props = ni.GetIPProperties();
                    foreach (UnicastIPAddressInformation addr in props.UnicastAddresses)
                    {
                        if (addr.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            string ipStr = addr.Address.ToString();
                            if (!ipStr.StartsWith("127.") && !ipStr.StartsWith("169.254."))
                            {
                                ips.Add(ipStr);
                            }
                        }
                    }
                }
            }
            catch { }
            return ips;
        }
    }
}
