using System;
using System.Collections.Generic;

namespace DivinaProvidencia
{
    public class User
    {
        public string Id { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string Salt { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; } // "admin", "coordinador", "secretaria"
        public string CreatedAt { get; set; }
    }

    public class Article
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Slug { get; set; }
        public string Category { get; set; } // "noticia", "evento", "academico", "comunicado"
        public string Summary { get; set; }
        public string Content { get; set; }
        public string ImageUrl { get; set; }
        public string Author { get; set; }
        public string PublishedAt { get; set; }
        public bool IsFeatured { get; set; }
        public bool IsPublished { get; set; }
    }

    public class Period
    {
        public string Time { get; set; }      // Ej: "07:00 - 07:45"
        public string Subject { get; set; }   // Ej: "Matemáticas"
        public string Teacher { get; set; }   // Ej: "Prof. Carlos Ramos"
        public string Room { get; set; }      // Ej: "Aula 3B"
    }

    public class DaySchedule
    {
        public string Day { get; set; }       // "Lunes", "Martes", "Miércoles", "Jueves", "Viernes"
        public List<Period> Periods { get; set; }

        public DaySchedule()
        {
            Periods = new List<Period>();
        }
    }

    public class Schedule
    {
        public string Id { get; set; }
        public string Level { get; set; }       // "Primaria", "Secundaria", "Bachillerato"
        public string Grade { get; set; }       // "1er Año", "2do Año", "3er Grado", etc.
        public string Section { get; set; }     // "A", "B", "C"
        public string Shift { get; set; }       // "Mañana", "Tarde"
        public string SchoolYear { get; set; }  // "2026-2027"
        public string Classroom { get; set; }   // "Aula 14"
        public string Coordinator { get; set; }// "Prof. Elena Méndez"
        public string UpdatedAt { get; set; }
        public List<DaySchedule> Days { get; set; }

        public Schedule()
        {
            Days = new List<DaySchedule>();
        }
    }

    public class Enrollment
    {
        public string Id { get; set; }
        public string Code { get; set; }              // "INS-2026-001"
        public string StudentFirstName { get; set; }
        public string StudentLastName { get; set; }
        public string StudentDocId { get; set; }
        public string BirthDate { get; set; }
        public string Gender { get; set; }
        public string GradeApplying { get; set; }
        public string AcademicYear { get; set; }
        public string PreviousSchool { get; set; }
        public string ParentFirstName { get; set; }
        public string ParentLastName { get; set; }
        public string ParentDocId { get; set; }
        public string ParentPhone { get; set; }
        public string ParentEmail { get; set; }
        public string ParentAddress { get; set; }
        public string Status { get; set; }            // "Pendiente", "Aprobado", "En Revisión", "Rechazado"
        public string AdminNotes { get; set; }
        public string SubmittedAt { get; set; }
        public string UpdatedAt { get; set; }
    }

    public class InstitutionSettings
    {
        public string SchoolName { get; set; }
        public string Slogan { get; set; }
        public string Mission { get; set; }
        public string Vision { get; set; }
        public string History { get; set; }
        public string Values { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string OfficeHours { get; set; }
        public string PrincipalName { get; set; }
        public bool EnrollmentOpen { get; set; }
        public string EnrollmentNotice { get; set; }
        public string WelcomeTitle { get; set; }
        public string WelcomeText { get; set; }
        public string PrimaryColor { get; set; }
        public string SecondaryColor { get; set; }
    }

    public class AuditLog
    {
        public string Id { get; set; }
        public string Timestamp { get; set; }
        public string User { get; set; }
        public string Action { get; set; }
        public string Details { get; set; }
    }

    public class DatabaseRoot
    {
        public InstitutionSettings Settings { get; set; }
        public List<User> Users { get; set; }
        public List<Article> Articles { get; set; }
        public List<Schedule> Schedules { get; set; }
        public List<Enrollment> Enrollments { get; set; }
        public List<AuditLog> AuditLogs { get; set; }

        public DatabaseRoot()
        {
            Users = new List<User>();
            Articles = new List<Article>();
            Schedules = new List<Schedule>();
            Enrollments = new List<Enrollment>();
            AuditLogs = new List<AuditLog>();
        }
    }
}
