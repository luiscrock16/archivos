@echo off
chcp 65001 > nul
title Colegio Divina Providencia - Servidor Local
echo =======================================================================
echo          INICIANDO SERVIDOR LOCAL - COLEGIO DIVINA PROVIDENCIA
echo =======================================================================
echo.

if not exist "ColegioServidor.exe" (
    echo No se encontró ColegioServidor.exe. Compilando por primera vez...
    call build.bat
)

echo Abriendo navegador en http://localhost:5000...
start "" http://localhost:5000

echo Iniciando servidor en el puerto 5000...
ColegioServidor.exe 5000
