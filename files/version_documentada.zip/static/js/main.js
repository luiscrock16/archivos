/**
 * =============================================================================
 * PROYECTO: THE FRAGANCE´S - ALTA PERFUMERÍA
 * ARCHIVO: main.js (VERSIÓN DOCUMENTADA)
 * =============================================================================
 * Este script maneja la interactividad del lado del cliente para toda la tienda:
 *  1. Alternador de Modo Claro / Modo Oscuro con persistencia en localStorage.
 *  2. Menú desplegable para dispositivos móviles (responsive).
 *  3. Auto-ocultación de notificaciones Flash tras unos segundos.
 * =============================================================================
 */

/**
 * Actualiza visualmente el interruptor de sol/luna y la clase 'dark' en <html>
 * @param {string} theme - 'light' para modo claro o 'dark' para modo oscuro.
 */
function updateThemeUI(theme) {
    const sunIcon = document.getElementById('themeSunIcon');
    const moonIcon = document.getElementById('themeMoonIcon');
    const toggleContainer = document.getElementById('themeToggleBtn');
    
    if (theme === 'light') {
        // Se retira la clase dark de <html> para activar las variables CSS del modo claro
        document.documentElement.classList.remove('dark');
        if (sunIcon) sunIcon.className = 'w-5 h-5 rounded-full bg-amber-400 text-black flex items-center justify-center text-[10px] shadow-sm';
        if (moonIcon) moonIcon.className = 'w-5 h-5 rounded-full text-slate-400 flex items-center justify-center text-[10px]';
        if (toggleContainer) toggleContainer.setAttribute('title', 'Cambiar a Modo Oscuro');
    } else {
        // Se añade la clase dark a <html> para activar las variables CSS del modo oscuro
        document.documentElement.classList.add('dark');
        if (sunIcon) sunIcon.className = 'w-5 h-5 rounded-full text-slate-500 flex items-center justify-center text-[10px]';
        if (moonIcon) moonIcon.className = 'w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center text-[10px] shadow-sm';
        if (toggleContainer) toggleContainer.setAttribute('title', 'Cambiar a Modo Claro');
    }
}

/**
 * Invierte el tema actual y guarda la elección del usuario en localStorage
 * para que se recuerde al recargar o cambiar de página.
 */
function toggleTheme() {
    const isDark = document.documentElement.classList.contains('dark');
    const newTheme = isDark ? 'light' : 'dark';
    localStorage.setItem('thefragances_theme', newTheme);
    updateThemeUI(newTheme);
}

// Inicialización cuando el DOM está completamente cargado
document.addEventListener('DOMContentLoaded', () => {
    // 1. Cargar el tema guardado en el navegador (por defecto oscuro)
    const savedTheme = localStorage.getItem('thefragances_theme') || 'dark';
    updateThemeUI(savedTheme);

    // 2. Asignar el evento click al botón del tema
    const themeBtn = document.getElementById('themeToggleBtn');
    if (themeBtn) {
        themeBtn.addEventListener('click', toggleTheme);
    }

    // 3. Menú móvil (hamburguesa)
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // 4. Auto-desvanecer alertas y mensajes flash después de 4 segundos
    const alerts = document.querySelectorAll('.flash-alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 4000);
    });
});
