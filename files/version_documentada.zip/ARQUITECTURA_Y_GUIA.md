# 📖 Guía de Arquitectura y Funcionamiento Interno
## Proyecto: The Fragance´s (Alta Perfumería Estilo Fragrantica)

Esta guía fue creada para que cualquier desarrollador, estudiante o propietario del proyecto pueda entender de manera clara y sencilla cómo está estructurado el sistema por dentro, cómo se comunican sus componentes y cómo modificarlo o ampliarlo.

---

## 🧭 1. Resumen y Filosofía del Proyecto

1. **Inspiración en Fragrantica:** Diseño visual oscuro y claro, pirámide olfativa completa (Salida, Corazón, Fondo), barras de acordes horizontales con colores y porcentajes.
2. **Sin Pasarela de Pago Compleja:** En lugar de carritos de compra tradicionales que reducen la conversión, cada perfume cuenta con un botón directo a **WhatsApp (+58 424-2567728)** con el mensaje ya redactado (nombre del perfume, presentación, precio).
3. **Control de Stock Ágil:** El dueño puede entrar desde su teléfono al panel y activar o desactivar el stock de cualquier perfume con **un solo toque** (tecnología AJAX, sin recargar la página).
4. **Reseñas Reales:** Solo usuarios registrados pueden opinar. Si hay un comentario inapropiado, el administrador puede borrarlo con un clic.

---

## 📁 2. Estructura de Carpetas

```text
pagina/
├── app.py                     # Servidor Flask principal y todas las rutas (URLs)
├── database.py                # Conexión con SQLite, creación de tablas y consultas
├── seed.py                    # Datos iniciales (carga los 20 perfumes y marcas del documento)
├── perfumes.db                # Base de datos SQLite (almacena todo localmente)
├── requirements.txt           # Librerías de Python requeridas (Flask, Gunicorn, etc.)
├── Procfile                   # Instrucción de arranque para servidores Linux / Render
├── render.yaml                # Archivo de configuración para despliegue automático
├── README.md                  # Instrucciones generales del proyecto
│
├── static/                    # Archivos estáticos públicos (CSS, JS, Imágenes)
│   ├── css/
│   │   └── custom.css         # Estilos personalizados, variables de tema claro/oscuro
│   ├── js/
│   │   ├── main.js            # Lógica del frontend (tema día/noche, menú móvil)
│   │   └── admin.js           # AJAX para cambiar stock en 1 clic y constructor de acordes
│   └── img/
│       ├── logo.svg           # Logo vectorial de la tienda
│       └── perfumes/          # Las 20 fotos reales de los frascos (PNG transparentes)
│
└── templates/                 # Vistas HTML con motor de plantillas Jinja2
    ├── base.html              # Plantilla maestra (Header, Navegación, Footer, Modo Noche)
    ├── index.html             # Página de inicio (Hero, Filtros, Grid de 20 perfumes)
    ├── catalog.html           # Buscador avanzado (por notas, género, precio)
    ├── detail.html            # Ficha del perfume (Pirámide olfativa, acordes, reseñas)
    ├── auth/
    │   ├── login.html         # Formulario de inicio de sesión
    │   ├── register.html      # Formulario de registro de clientes
    │   └── profile.html       # Perfil del usuario y sus reseñas publicadas
    └── admin/
        ├── dashboard.html     # Panel principal con control de stock rápido
        ├── perfume_form.html  # Formulario para añadir o editar perfumes
        ├── perfumes_list.html # Lista completa de perfumes en inventario
        ├── reviews_list.html  # Moderación y eliminación de reseñas
        ├── users_list.html    # Lista de clientes registrados
        └── settings.html      # Configuración (WhatsApp, nombre de tienda, etc.)
```

---

## 🗄️ 3. Base de Datos (database.py)

El sistema utiliza **SQLite**, una base de datos relacional ligera embebida que no requiere configurar servidores externos como MySQL o PostgreSQL.

### Tablas principales:
1. **`settings` (Configuración del Sitio):**
   - Guarda pares clave/valor como el teléfono de WhatsApp (`584242567728`), nombre de la tienda (`The Fragance´s`), símbolo de moneda (`$`), etc.
2. **`users` (Usuarios y Administradores):**
   - Campos: `id`, `name`, `email`, `password_hash`, `phone`, `role` (`cliente` o `admin`).
   - Las contraseñas se encriptan con `generate_password_hash` de Werkzeug (seguridad SHA-256 con salt).
3. **`brands` (Casas de Perfumería):**
   - Dior, Chanel, Lattafa, Jean Paul Gaultier, etc.
4. **`perfumes` (Catálogo de Fragancias):**
   - Nombre, slug (URL amigable), género (`Hombre`, `Mujer`, `Unisex`), presentación oficial, precio, rango de precio (`$150–$170`), `in_stock` (1 = disponible, 0 = agotado), imagen local (`/static/img/perfumes/...`).
   - **Campos JSON:** Para permitir flexibilidad olfativa sin crear decenas de tablas auxiliares, los acordes y notas se guardan serializados como JSON:
     - `accords`: `[{"name": "Canela", "color": "#B45309", "percent": 90}, ...]`
     - `top_notes`: `["Mandarina", "Toronja", "Menta"]` (Notas de Salida)
     - `heart_notes`: `["Canela", "Rosa"]` (Notas de Corazón)
     - `base_notes`: `["Ámbar", "Cuero"]` (Notas de Fondo)
5. **`reviews` (Reseñas de Compradores):**
   - Relaciona un usuario con un perfume, calificación (1 a 5 estrellas) y comentario.
   - Cada vez que se añade o elimina una reseña, se ejecuta `AVG(rating)` y se actualiza el promedio del perfume automáticamente.

---

## ⚙️ 4. Servidor y Rutas (app.py)

Flask maneja las solicitudes HTTP mediante decoradores `@app.route`:

### A. Rutas Públicas de la Tienda:
- **`GET /` (`index`):** Carga los 20 perfumes divididos por género (Caballeros, Damas, Nicho), la fragancia destacada (Bleu de Chanel) y las reseñas recientes.
- **`GET /catalogo` (`catalog`):** Buscador con filtros combinables: texto libre (busca en nombre, marca y notas), género, acorde y filtro de solo en stock.
- **`GET /perfume/<slug>` (`perfume_detail`):** Vista detallada de un perfume con su pirámide olfativa renderizada visualmente y formulario de reseñas.

### B. Rutas de Clientes:
- **`POST /registro` (`user_register`):** Crea cuenta de cliente verificando que el email no exista.
- **`POST /login` (`user_login`):** Valida credenciales. Si el usuario es administrador, su sesión guardará `role = 'admin'` y se le desplegará el panel de control.
- **`GET /logout` (`user_logout`):** Destruye la sesión de forma segura.
- **`POST /perfume/<slug>/resena` (`submit_review`):** Permite a un cliente logueado publicar una reseña.

### C. Rutas del Administrador (Protegidas):
- **`POST /api/toggle-stock/<id>`:** Endpoint AJAX. Invierte el estado de stock (de 1 a 0 o de 0 a 1) y devuelve un JSON.
- **`POST /admin/resenas/eliminar/<id>`:** Borra un comentario y redirige a la página donde estaba el admin (con `request.referrer`).
- **`GET /admin/perfumes`:** Lista de productos para editar o eliminar.
- **`POST /admin/perfumes/nuevo`:** Crea un perfume con constructor dinámico de acordes visuales.

---

## ⚡ 5. Control de Stock en 1 Clic (AJAX)

Para que el dueño no tenga que recargar la página ni entrar a formularios complicados desde su teléfono móvil:

1. El botón en el dashboard tiene un evento: `onclick="toggleStock({{ perfume.id }}, this)"`.
2. En `static/js/admin.js`, la función `toggleStock` hace una petición silenciosa mediante `fetch('/api/toggle-stock/' + id, {method: 'POST'})`.
3. El servidor actualiza la base de datos y responde: `{"success": true, "in_stock": 0}`.
4. El JavaScript actualiza el color del botón y la etiqueta en pantalla inmediatamente.

---

## 🎨 6. Sistema de Modo Claro y Oscuro

En lugar de recargar la página o usar librerías pesadas:
- Se definieron **Variables CSS** en `static/css/custom.css` (`--bg-main`, `--bg-card`, `--text-main`, `--border-subtle`).
- En `static/js/main.js`, al pulsar el botón del sol/luna se añade o quita la clase `dark` de la etiqueta `<html>`.
- La preferencia se guarda en el navegador con `localStorage.setItem('thefragances_theme', 'light')`, de modo que al navegar entre páginas la elección se mantiene.
- En `templates/base.html` hay un script en el `<head>` que lee este valor antes de pintar la pantalla, evitando cualquier parpadeo de luz.

---

## 📲 7. Enlace Directo a WhatsApp

Cada frasco genera dinámicamente un enlace estructurado con la API oficial de WhatsApp:
```html
https://wa.me/{{ settings.whatsapp_number }}?text=¡Hola!%20Me%20interesa%20el%20perfume%20*{{ perfume.name }}*%20({{ perfume.presentation }}).
```
Al tocar el botón desde una computadora se abre WhatsApp Web; desde un teléfono móvil se abre la aplicación nativa de WhatsApp con el mensaje listo para enviar.

---

## 🚀 8. Cómo Ejecutar el Proyecto Localmente

1. Tener Python 3 instalado.
2. Abrir la terminal en la carpeta del proyecto.
3. Instalar librerías:
   ```bash
   pip install -r requirements.txt
   ```
4. Iniciar el servidor:
   ```bash
   python app.py
   ```
5. Abrir en el navegador: `http://127.0.0.1:5000`

---
*The Fragance´s — Arquitectura limpia, moderna y lista para escalar.*
