@echo off
setlocal EnableDelayedExpansion
title Reparar Servicios de Descarga en MiniOS 10
color 0e

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
cls
echo ======================================================================
echo       REPARAR SERVICIOS DE DESCARGA E INSTALACION EN MINIOS 10
echo ======================================================================
echo.
echo En los sistemas MiniOS 10, los servicios de descarga en segundo plano
echo suelen venir desactivados de fabrica, lo que impide que instaladores
echo como Office puedan conectarse a internet.
echo.
echo Reactivando servicios necesarios...
echo.

echo 1. Servicio de Transferencia Inteligente en Segundo Plano (BITS)...
sc config bits start= auto >nul 2>&1
net start bits >nul 2>&1

echo 2. Servicio de Optimizacion de Entrega (DoSvc)...
sc config dosvc start= auto >nul 2>&1
net start dosvc >nul 2>&1

echo 3. Servicio de Windows Update (wuauserv)...
sc config wuauserv start= auto >nul 2>&1
net start wuauserv >nul 2>&1

echo 4. Servicio Criptografico (CryptSvc)...
sc config cryptsvc start= auto >nul 2>&1
net start cryptsvc >nul 2>&1

echo.
echo ======================================================================
echo                 SERVICIOS ACTIVADOS CORRECTAMENTE
echo ======================================================================
echo.
echo Si tienes internet en la Canaima, ahora el instalador podra descargar.
echo Sin embargo, si copiaste la carpeta "Office" completa en este pendrive,
echo el instalador se ejecutara de forma 100%% OFFLINE sin usar internet.
echo.
pause
