@echo off
cd /d "%~dp0"
title Instalador de Office Completo - Canaimas (MiniOS 10)
color 0b

echo ======================================================================
echo       INSTALADOR DE OFFICE COMPLETO PARA CANAIMA (MiniOS 10)
echo         Arquitectura: 32 bits (x86) - Suite Profesional
echo ======================================================================
echo.
echo Aplicaciones que se van a instalar:
echo   - Microsoft Word, Excel, PowerPoint
echo   - Microsoft Outlook, OneNote, Access, Publisher
echo.
if exist "Office" (
    echo [MODO DETECTADO]: INSTALACION LOCAL OFFLINE.
) else (
    echo [MODO DETECTADO]: INSTALACION EN LINEA (Descarga directa desde Microsoft).
    echo Asegurate de que la Canaima este conectada a Internet.
)
echo.
if not exist "setup.exe" (
    echo [ERROR CRITICO]: No se encontro 'setup.exe' en esta carpeta.
    pause
    exit /b
)
if not exist "config_canaima_completo.xml" (
    echo [ERROR CRITICO]: No se encontro 'config_canaima_completo.xml'.
    pause
    exit /b
)

echo Presiona cualquier tecla para comenzar...
pause >nul
echo.
echo Instalando Office Completo... Por favor espera.
setup.exe /configure config_canaima_completo.xml

echo.
echo ======================================================================
echo                      INSTALACION FINALIZADA
echo ======================================================================
pause
